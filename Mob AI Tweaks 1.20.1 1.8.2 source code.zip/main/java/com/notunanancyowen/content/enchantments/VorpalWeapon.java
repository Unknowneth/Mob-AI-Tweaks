package com.notunanancyowen.content.enchantments;

import com.notunanancyowen.MobAITweaks;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalEntityTypeTags;
import net.minecraft.enchantment.DamageEnchantment;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.PhantomEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;

public class VorpalWeapon extends Enchantment {
    public VorpalWeapon() {
        super(Rarity.VERY_RARE, EnchantmentTarget.BREAKABLE, new EquipmentSlot[]{EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND});
    }
    @Override public int getMaxLevel() {
        return 5;
    }
    @Override public boolean isAvailableForEnchantedBookOffer() {
        return false;
    }
    @Override public boolean isAvailableForRandomSelection() {
        return false;
    }
    @Override protected boolean canAccept(Enchantment other) {
        return !(other instanceof DamageEnchantment)  && super.canAccept(other);
    }
    @Override public boolean isAcceptableItem(ItemStack stack) {
        return stack.getItem() instanceof RangedWeaponItem || stack.getItem() instanceof ToolItem;
    }
    @Override public void onTargetDamaged(LivingEntity user, Entity target, int level) {
        if(target.getType().isIn(ConventionalEntityTypeTags.BOSSES) || target.getType().isIn(MobAITweaks.BOSS_THAT_ANNOUNCES_SUMMON) || target.getType().isIn(MobAITweaks.BOSS_THAT_ANNOUNCES_DEFEAT) || (target instanceof PhantomEntity p && p.handSwingProgress == 1F)) {
            if(user instanceof PlayerEntity p) p.addEnchantedHitParticles(target);
            if(target instanceof LivingEntity l) l.setHealth(l.getHealth() - 1.5F * level);
        }
        super.onTargetDamaged(user, target, level);
    }
}
