package com.notunanancyowen.content.enchantments;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;

public class GrapplingBobber extends Enchantment {
    public GrapplingBobber() {
        super(Rarity.VERY_RARE, EnchantmentTarget.FISHING_ROD, new EquipmentSlot[]{EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND});
    }
    @Override public boolean isAvailableForEnchantedBookOffer() {
        return false;
    }
    @Override public boolean isAvailableForRandomSelection() {
        return false;
    }
    @Override protected boolean canAccept(Enchantment other) {
        return other != Enchantments.LUCK_OF_THE_SEA && other != Enchantments.LURE && super.canAccept(other);
    }
}
