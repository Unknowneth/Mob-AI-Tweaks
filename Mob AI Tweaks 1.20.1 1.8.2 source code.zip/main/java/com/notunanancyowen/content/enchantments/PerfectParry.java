package com.notunanancyowen.content.enchantments;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.FlintAndSteelItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ShieldItem;

public class PerfectParry extends Enchantment {
    public PerfectParry() {
        super(Rarity.VERY_RARE, EnchantmentTarget.VANISHABLE, new EquipmentSlot[]{EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND});
    }
    @Override public int getMaxLevel() {
        return 4;
    }
    @Override public boolean isAvailableForEnchantedBookOffer() {
        return false;
    }
    @Override public boolean isAvailableForRandomSelection() {
        return false;
    }
    @Override public boolean isAcceptableItem(ItemStack stack) {
        return stack.getItem() instanceof ShieldItem;
    }
}
