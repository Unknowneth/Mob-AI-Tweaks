package com.notunanancyowen.content.enchantments;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.RangedWeaponItem;
import net.minecraft.item.TridentItem;
import net.minecraft.world.World;

public class BlastingImpression extends Enchantment {
    public BlastingImpression() {
        super(Rarity.VERY_RARE, EnchantmentTarget.VANISHABLE, new EquipmentSlot[]{EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND});
    }
    @Override public int getMaxLevel() {
        return 3;
    }
    @Override public boolean isAvailableForEnchantedBookOffer() {
        return false;
    }
    @Override public boolean isAvailableForRandomSelection() {
        return false;
    }
    @Override protected boolean canAccept(Enchantment other) {
        return other != Enchantments.RIPTIDE && super.canAccept(other);
    }
    @Override public boolean isAcceptableItem(ItemStack stack) {
        return stack.getItem() instanceof RangedWeaponItem || stack.getItem() instanceof TridentItem;
    }
    @Override public void onTargetDamaged(LivingEntity user, Entity target, int level) {
        if(!user.getWorld().isClient()) user.getWorld().createExplosion(user, target.getX(), target.getBodyY(1F / 3F), target.getZ(), level * 0.5F, World.ExplosionSourceType.NONE);
    }
}
