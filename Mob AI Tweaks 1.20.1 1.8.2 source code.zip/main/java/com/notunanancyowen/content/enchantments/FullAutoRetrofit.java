package com.notunanancyowen.content.enchantments;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.EquipmentSlot;

public class FullAutoRetrofit extends Enchantment {
    public FullAutoRetrofit() {
        super(Rarity.VERY_RARE, EnchantmentTarget.CROSSBOW, new EquipmentSlot[]{EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND});
    }
    @Override public boolean isAvailableForEnchantedBookOffer() {
        return false;
    }
    @Override public boolean isAvailableForRandomSelection() {
        return false;
    }
    @Override protected boolean canAccept(Enchantment other) {
        return !(other instanceof AutoLoadingHolster) && super.canAccept(other);
    }
}
