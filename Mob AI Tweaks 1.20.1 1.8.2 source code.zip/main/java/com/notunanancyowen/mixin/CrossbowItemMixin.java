package com.notunanancyowen.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import com.notunanancyowen.content.enchantments.AutoLoadingHolster;
import com.notunanancyowen.content.enchantments.FeatherweightMunitions;
import com.notunanancyowen.content.enchantments.FullAutoRetrofit;
import com.notunanancyowen.content.enchantments.WitheringMunitions;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.*;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.RangedWeaponItem;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(CrossbowItem.class)
public abstract class CrossbowItemMixin extends RangedWeaponItem {
    @Unique private int autoReloadTime = 0;
    public CrossbowItemMixin(Settings settings) {
        super(settings);
    }
    @Inject(method = "shoot", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;damage(ILnet/minecraft/entity/LivingEntity;Ljava/util/function/Consumer;)V"))
    private static void replaceWithSkull(World world, LivingEntity shooter, Hand hand, ItemStack crossbow, ItemStack projectile, float soundPitch, boolean creative, float speed, float divergence, float simulated, CallbackInfo ci, @Local(index = 11) LocalRef<ProjectileEntity> projectileEntity) {
        if(projectileEntity != null) EnchantmentHelper.get(crossbow).keySet().forEach(e -> {
            if(projectileEntity.get() == null) return;
            if(e instanceof FeatherweightMunitions) {
                projectileEntity.get().setNoGravity(true);
                if(shooter instanceof PathAwareEntity mob && mob.getTarget() != null) projectileEntity.get().setVelocity(mob.getTarget().getEyePos().subtract(projectileEntity.get().getPos()).normalize().multiply(projectileEntity.get().getVelocity().length()));
                return;
            }
            if(e instanceof WitheringMunitions) {
                var velocity = projectileEntity.get().getVelocity();
                if(shooter instanceof PathAwareEntity mob && mob.getTarget() != null) velocity = mob.getTarget().getEyePos().subtract(projectileEntity.get().getPos()).normalize().multiply(velocity.length());
                WitherSkullEntity skull = new WitherSkullEntity(world, shooter, velocity.x, velocity.y, velocity.z);
                skull.setFireTicks(projectileEntity.get().getFireTicks());
                skull.setPosition(projectileEntity.get().getPos());
                skull.setCharged(!projectile.isOf(Items.ARROW));
                projectileEntity.set(skull);
            }
        });
    }
    @Inject(method = "usageTick", at = @At("TAIL"))
    private void fullAuto(World world, LivingEntity user, ItemStack stack, int remainingUseTicks, CallbackInfo ci) {
        if(world.isClient() || remainingUseTicks > 0 || CrossbowItem.isCharged(stack) || EnchantmentHelper.get(stack).keySet().stream().noneMatch(e -> e instanceof FullAutoRetrofit)) return;
        user.stopUsingItem();
    }
    @Override public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if(entity instanceof PlayerEntity player && !world.isClient() && !selected && !CrossbowItem.isCharged(stack) && EnchantmentHelper.get(stack).keySet().stream().anyMatch(e -> e instanceof AutoLoadingHolster)) if(++autoReloadTime > stack.getMaxUseTime()) stack.onStoppedUsing(world, player, autoReloadTime = 0);
        else stack.usageTick(world, player, autoReloadTime);
        super.inventoryTick(stack, world, entity, slot, selected);
    }
}
