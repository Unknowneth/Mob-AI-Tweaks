package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import net.minecraft.block.SkullBlock;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.Brain;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.passive.AllayEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.entity.projectile.WitherSkullEntity;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Comparator;
import java.util.List;

@Mixin(AllayEntity.class)
public abstract class AllayEntityMixin extends PathAwareEntity {
    @Shadow public abstract Brain<AllayEntity> getBrain();
    @Shadow public abstract void travel(Vec3d movementInput);
    @Shadow public abstract void setDancing(boolean dancing);
    @Shadow public abstract boolean isPanicking();
    AllayEntityMixin(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
    }
    @Inject(method = "mobTick", at = @At("HEAD"), cancellable = true)
    private void defendLikedPlayer(CallbackInfo ci) {
        if(!MobAITweaks.getModConfigValue("allay_rework")) return;
        setAttacking(getMainHandStack().getItem() instanceof BowItem || getMainHandStack().getItem() instanceof CrossbowItem || getMainHandStack().getItem() instanceof ToolItem);
        if(isPanicking()) {
            stopUsingItem();
            return;
        }
        if(getTarget() != null) if(attackMobsPerhaps(getTarget())) {
            super.mobTick();
            ci.cancel();
            if(getTarget().isAlive()) return;
            setTarget(null);
            stopUsingItem();
            return;
        }
        if(age % 20 == 0) getBrain().getOptionalRegisteredMemory(MemoryModuleType.LIKED_NOTEBLOCK).ifPresent(n -> {
            if(getWorld().getBlockState(n.getPos().up()).getBlock() instanceof SkullBlock skullType) {
                SkullBlock.SkullType type = skullType.getSkullType();
                if(type.equals(SkullBlock.Type.CREEPER)) {
                    List<HostileEntity> list1 = getWorld().getEntitiesByClass(HostileEntity.class, getBoundingBox().expand(16.0, 16.0, 16.0), h -> (h instanceof SpiderEntity || h instanceof CreeperEntity) && distanceTo(h) < 16);
                    if(list1.isEmpty()) return;
                    list1.sort(Comparator.comparing(this::distanceTo));
                    attackMobsPerhaps(list1.get(0));
                }
                else if(type.equals(SkullBlock.Type.ZOMBIE)) {
                    List<HostileEntity> list2 = getWorld().getEntitiesByClass(HostileEntity.class, getBoundingBox().expand(16.0, 16.0, 16.0), h -> h.isUndead() && distanceTo(h) < 16);
                    if(list2.isEmpty()) return;
                    list2.sort(Comparator.comparing(this::distanceTo));
                    attackMobsPerhaps(list2.get(0));
                }
                else if(type.equals(SkullBlock.Type.SKELETON)) {
                    List<HostileEntity> list3 = getWorld().getEntitiesByClass(HostileEntity.class, getBoundingBox().expand(16.0, 16.0, 16.0), h -> distanceTo(h) < 16);
                    if(list3.isEmpty()) return;
                    list3.sort(Comparator.comparing(this::distanceTo));
                    attackMobsPerhaps(list3.get(0));
                }
                else if(type.equals(SkullBlock.Type.WITHER_SKELETON)) {
                    List<LivingEntity> list4 = getWorld().getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(16.0, 16.0, 16.0), h -> !(h instanceof AllayEntity) && h.isSpectator() && h.isInvulnerable() && distanceTo(h) < 16);
                    if(list4.isEmpty()) return;
                    list4.sort(Comparator.comparing(this::distanceTo));
                    attackMobsPerhaps(list4.get(0));
                }
                else if(type.equals(SkullBlock.Type.PIGLIN)) {
                    List<AnimalEntity> list5 = getWorld().getEntitiesByClass(AnimalEntity.class, getBoundingBox().expand(16.0, 16.0, 16.0), h -> distanceTo(h) < 16);
                    if(list5.isEmpty()) return;
                    list5.sort(Comparator.comparing(this::distanceTo));
                    attackMobsPerhaps(list5.get(0));
                }
                else if(type.equals(SkullBlock.Type.PLAYER)) {
                    List<PlayerEntity> list6 = getWorld().getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(16.0, 16.0, 16.0), h -> !h.isSpectator() && !h.isCreative() && distanceTo(h) < 16);
                    if(list6.isEmpty()) return;
                    list6.sort(Comparator.comparing(this::distanceTo));
                    attackMobsPerhaps(list6.get(0));
                }
            }
        });
        getBrain().getOptionalRegisteredMemory(MemoryModuleType.LIKED_PLAYER).ifPresent(s -> {
            if(getServer() != null) {
                PlayerEntity player = getServer().getPlayerManager().getPlayer(s);
                if(player != null) if(player.getAttacker() != null) if(attackMobsPerhaps(player.getAttacker())) {
                    super.mobTick();
                    ci.cancel();
                }
                else stopUsingItem();
            }
        });
    }
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void avoidFriendlyFire(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if(source.getAttacker() instanceof AllayEntity || source.getSource() instanceof AllayEntity) cir.setReturnValue(false);
    }
    @Inject(method = "tick", at = @At("HEAD"))
    private void tickHandSwingFix(CallbackInfo ci) {
        tickHandSwing();
    }
    @Unique private boolean attackMobsPerhaps(LivingEntity target) {
        if(!MobAITweaks.getModConfigValue("allay_rework")) return false;
        var itemId = Registries.ITEM.getId(getMainHandStack().getItem());
        if(MobAITweaks.allayItemBlacklist.contains(itemId.getNamespace() + ":" + itemId.getPath())) return false;
        boolean canLookAtTarget = false;
        if(getMainHandStack().isOf(Items.FIRE_CHARGE)) {
            Vec3d offset = getRotationVector(0f, getYaw());
            offset = target.getPos().add(offset.getX() * -5.19615d, 9d, offset.getZ() * -5.19615d).add(target.getVelocity());
            if(squaredDistanceTo(offset) < 36 && (age / 21) % 2 == 0 && age % 7 == 0) {
                SmallFireballEntity fireball = new SmallFireballEntity(getWorld(), this, getRotationVector().getX(), getRotationVector().getY(), getRotationVector().getZ());
                fireball.setVelocity(fireball.getVelocity().getX(), fireball.getVelocity().getY(),fireball.getVelocity().getZ(), 1, 1);
                fireball.setPosition(getEyePos());
                getWorld().spawnEntity(fireball);
                getWorld().playSound(this, getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.NEUTRAL, 1f, getWorld().getRandom().nextFloat() * 0.4f + 0.8f);
            }
            setVelocity(offset.subtract(getPos()).normalize().multiply(getAttributeValue(EntityAttributes.GENERIC_FLYING_SPEED) * 1.5d));
            canLookAtTarget = true;
        }
        else if(getMainHandStack().getItem() instanceof CrossbowItem crossbow) {
            Vec3d offset = getRotationVector(0f, getYaw());
            offset = target.getPos().add(offset.getX() * -12d, 4.36765d, offset.getZ() * -12d).add(target.getVelocity());
            if(squaredDistanceTo(offset) < 144) setCurrentHand(Hand.MAIN_HAND);
            int arrowCount = 1;
            if(getMainHandStack().getEnchantments().stream().anyMatch(e -> e.asString().contains("minecraft:multishot"))) arrowCount = 3;
            if(getItemUseTime() >= crossbow.getMaxUseTime(getMainHandStack()) * 2) for(int i = 0; i < arrowCount; i++) if(getMainHandStack().getEnchantments().stream().anyMatch(e -> e.asString().contains(MobAITweaks.MOD_ID + "withering_munitions"))) {
                Vec3d shootTo = getRotationVector().multiply(1.5d).rotateY(i > 0 ? arrowCount * (float)(Math.PI * 0.1d) - i * (float)(Math.PI * 0.2d) : 0F);
                WitherSkullEntity skull = new WitherSkullEntity(getWorld(), this, shootTo.getX(), shootTo.getY(), shootTo.getZ());
                getWorld().spawnEntity(skull);
                if(i != 0) continue;
                stopUsingItem();
                getWorld().playSound(this, getBlockPos(), SoundEvents.ENTITY_WITHER_SHOOT, SoundCategory.NEUTRAL, 1f, getWorld().getRandom().nextFloat() * 0.4f + 0.8f);
            }
            else {
                ArrowEntity arrow = new ArrowEntity(getWorld(), getX(), getEyeY(), getZ());
                arrow.initFromStack(Items.ARROW.getDefaultStack());
                arrow.setOwner(this);
                arrow.setPosition(getEyePos());
                arrow.setVelocity(getRotationVector().multiply(3.2d).rotateY(i > 0 ? arrowCount * (float)(Math.PI * 0.1d) - i * (float)(Math.PI * 0.2d) : 0F));
                arrow.setCritical(true);
                if(getMainHandStack().getEnchantments().stream().anyMatch(e -> e.asString().contains(MobAITweaks.MOD_ID + "featherweight_munitions"))) arrow.setNoGravity(true);
                getWorld().spawnEntity(arrow);
                if(i > 0) continue;
                stopUsingItem();
                getWorld().playSound(this, getBlockPos(), SoundEvents.ITEM_CROSSBOW_SHOOT, SoundCategory.NEUTRAL, 1f, getWorld().getRandom().nextFloat() * 0.4f + 0.8f);
            }
            setVelocity(offset.subtract(getPos()).normalize().multiply(getAttributeValue(EntityAttributes.GENERIC_FLYING_SPEED) * 1.5d));
            canLookAtTarget = true;
        }
        else if(getMainHandStack().getItem() instanceof BowItem) {
            Vec3d offset = getRotationVector(0f, getYaw());
            offset = target.getPos().add(offset.getX() * -9d, 5.19615d, offset.getZ() * -9d).add(target.getVelocity());
            if(squaredDistanceTo(offset) < 49) setCurrentHand(Hand.MAIN_HAND);
            if(getItemUseTime() >= 20) {
                ArrowEntity arrow = new ArrowEntity(getWorld(), getX(), getEyeY(), getZ());
                arrow.initFromStack(Items.ARROW.getDefaultStack());
                arrow.setOwner(this);
                arrow.setPosition(getEyePos());
                arrow.setVelocity(getRotationVector().multiply(1.6d));
                arrow.setCritical(true);
                if(getMainHandStack().getEnchantments().stream().anyMatch(e -> e.asString().contains("minecraft:flame"))) arrow.setFireTicks(300);
                getWorld().spawnEntity(arrow);
                stopUsingItem();
                getWorld().playSound(this, getBlockPos(), SoundEvents.ENTITY_SKELETON_SHOOT, SoundCategory.NEUTRAL, 1f, getWorld().getRandom().nextFloat() * 0.4f + 0.8f);
            }
            setVelocity(offset.subtract(getPos()).normalize().multiply(getAttributeValue(EntityAttributes.GENERIC_FLYING_SPEED) * 1.5d));
            canLookAtTarget = true;
        }
        else if(getMainHandStack().getItem() instanceof ToolItem) {
            if(getBoundingBox().intersects(target.getBoundingBox()) && tryAttack(target)) swingHand(Hand.MAIN_HAND);
            else setVelocity(target.getEyePos().subtract(getPos()).normalize().multiply(getAttributeValue(EntityAttributes.GENERIC_FLYING_SPEED) * 1.5d));
            canLookAtTarget = true;
        }
        if(canLookAtTarget) {
            if(!target.equals(getTarget())) setTarget(target);
            setDancing(false);
            lookAtEntity(target, 30f, 30f);
            getLookControl().lookAt(target, 60f, 60f);
            getNavigation().stop();
        }
        return canLookAtTarget;
    }
}
