package com.notunanancyowen.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.notunanancyowen.MobAITweaks;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.PathAwareEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MeleeAttackGoal.class)
public abstract class MeleeAttackGoalMixin {
    @Shadow @Final protected PathAwareEntity mob;
    @Shadow @Final  private double speed;
    @Shadow private Path path;
    @Shadow protected abstract void resetCooldown();
    @Shadow private int cooldown;
    @ModifyReturnValue(method="shouldContinue()Z", at = @At(value = "RETURN", ordinal = 2))
    public boolean keepAttacking(boolean canContinue) {
        if (!canContinue && mob.distanceTo(mob.getTarget()) < 10) {
            path = mob.getNavigation().findPathTo(mob.getTarget(), 0);
            mob.getNavigation().startMovingAlong(path, speed);
            return true;
        }
        return canContinue;
    }
    @Inject(method = "tick", at = @At("TAIL"))
    private void jumpToReachTarget(CallbackInfo ci) {
        if(MobAITweaks.getModConfigValue("melee_mobs_jump_to_reach") && cooldown == 0 && mob.getWorld().getDifficulty().getId() > 2 && !mob.handSwinging && mob.isOnGround() && mob.getBoundingBox().getXLength() < 0.8d && mob.getBoundingBox().getZLength() < 0.8d && mob.getBoundingBox().getYLength() > 1d && mob.getTarget() != null && mob.squaredDistanceTo(mob.getTarget().getX(), mob.getY(), mob.getTarget().getZ()) < Math.pow(mob.getBoundingBox().getXLength() + mob.getBoundingBox().getZLength(), 2) && mob.canSee(mob.getTarget())) {
            double yDist = mob.getTarget().getY() - mob.getEyeY();
            double maxDistForJump = 0.9d * mob.getScaleFactor() + mob.getJumpBoostVelocityModifier();
            if(yDist > 0.2d && yDist < maxDistForJump) mob.getJumpControl().setActive();
        }
    }
    @Inject(method = "start", at = @At("TAIL"))
    private void resetAttackCooldownProperly(CallbackInfo ci) {
        resetCooldown();
    }
    @Inject(method = "resetCooldown", at = @At("TAIL"))
    private void resetAttack(CallbackInfo ci) {
        if(mob.hasStatusEffect(StatusEffects.MINING_FATIGUE)) {
            var fatigueLevel = mob.getStatusEffect(StatusEffects.MINING_FATIGUE);
            if(fatigueLevel != null) cooldown += (fatigueLevel.getAmplifier() + 1) * 2;
        }
        if(mob.hasStatusEffect(StatusEffects.HASTE)) {
            var hasteLevel = mob.getStatusEffect(StatusEffects.HASTE);
            if(hasteLevel != null) cooldown -= (hasteLevel.getAmplifier() + 1) * 2;
            if(cooldown < 6) cooldown = 6;
        }
        if(mob.getWorld().getGameRules().getBoolean(MobAITweaks.MOBS_ARE_OP)) mob.addVelocity(mob.getRotationVector().multiply(speed, 0d, speed));
    }
}
