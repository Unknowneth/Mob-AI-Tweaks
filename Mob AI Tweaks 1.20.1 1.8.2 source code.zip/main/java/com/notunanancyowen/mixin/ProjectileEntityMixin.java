package com.notunanancyowen.mixin;

import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;


@Mixin(ProjectileEntity.class)
public abstract class ProjectileEntityMixin {
    @ModifyArg(method = "setVelocity(DDDFF)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/random/Random;nextTriangular(DD)D"), index = 1)
    private double becomeInaccurateWhenNauseous(double uncertainty) {
        ProjectileEntity me = (ProjectileEntity)(Object)this;
        if(me.getOwner() instanceof MobEntity m && m.hasStatusEffect(StatusEffects.NAUSEA)) uncertainty = 0.0172275 * (uncertainty + Math.sqrt(m.getStatusEffect(StatusEffects.NAUSEA).getAmplifier() / 255F) * 122.5 + 10);
        return uncertainty;
    }
}
