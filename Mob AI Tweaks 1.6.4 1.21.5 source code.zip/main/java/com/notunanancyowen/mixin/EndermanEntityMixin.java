package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.FleeEntityGoal;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.mob.Angerable;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EndermanEntity.class)
public abstract class EndermanEntityMixin extends HostileEntity implements Angerable {
    EndermanEntityMixin(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
    }
    @Inject(method = "initGoals", at = @At("HEAD"))
    private void runAwayFromDragonDuringDamagePhase(CallbackInfo ci) {
        if (MobAITweaks.getModConfigValue("ender_dragon_rework")) goalSelector.add(0, new FleeEntityGoal<>(this, EnderDragonEntity.class, 128F, 1.0F, 1.25F, e -> e instanceof EnderDragonEntity dragon && dragon.getPhaseManager().getCurrent().isSittingOrHovering()) {
            @Override public void start() {
                setTarget(null);
                setAngerTime(0);
                super.start();
            }
        });
    }
}
