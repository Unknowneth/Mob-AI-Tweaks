package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.entity.CrossbowUser;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.ai.brain.task.CrossbowAttackTask;
import net.minecraft.entity.ai.brain.task.TargetUtil;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.CrossbowItem;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(CrossbowAttackTask.class)
public abstract class RangedCrossbowAttackTaskMixin {
    @Shadow private int chargingCooldown;
    @Inject(method = "shouldRun(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/entity/mob/MobEntity;)Z", at = @At("HEAD"), cancellable = true)
    private void fixCrossbowCheckForTask(ServerWorld serverWorld, MobEntity mobEntity, CallbackInfoReturnable<Boolean> cir) {
        LivingEntity target = mobEntity.getBrain().getOptionalRegisteredMemory(MemoryModuleType.ATTACK_TARGET).orElse(mobEntity.getTarget());
        boolean hasCrossbow = mobEntity.getMainHandStack().getItem() instanceof CrossbowItem || mobEntity.getOffHandStack().getItem() instanceof CrossbowItem;
        cir.setReturnValue(hasCrossbow && TargetUtil.isVisibleInMemory(mobEntity, target) && TargetUtil.isTargetWithinAttackRange(mobEntity, target, 0));
    }
    @Inject(method = "finishRunning(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/entity/mob/MobEntity;J)V", at = @At("TAIL"))
    private void fixCrossbowUnchargerCheck(ServerWorld serverWorld, MobEntity mobEntity, long l, CallbackInfo ci) {
        if(mobEntity.getMainHandStack().getItem() instanceof CrossbowItem && CrossbowItem.isCharged(mobEntity.getMainHandStack())) {
            if(mobEntity instanceof CrossbowUser ranger) ranger.setCharging(false);
            mobEntity.getActiveItem().set(DataComponentTypes.CHARGED_PROJECTILES, ChargedProjectilesComponent.DEFAULT);
        }
        else if(mobEntity.getOffHandStack().getItem() instanceof CrossbowItem && CrossbowItem.isCharged(mobEntity.getOffHandStack())) {
            if(mobEntity instanceof CrossbowUser ranger) ranger.setCharging(false);
            mobEntity.getActiveItem().set(DataComponentTypes.CHARGED_PROJECTILES, ChargedProjectilesComponent.DEFAULT);
        }
        chargingCooldown = -6;
    }
    @Inject(method = "tickState", at = @At("HEAD"), cancellable = true)
    private void addSomeDelayBetweenShots(MobEntity entity, LivingEntity target, CallbackInfo ci) {
        if(!CrossbowItem.isCharged(entity.getMainHandStack().getItem() instanceof CrossbowItem ? entity.getMainHandStack() : entity.getOffHandStack()) && chargingCooldown > -6) {
            chargingCooldown--;
            ci.cancel();
        }
        if(entity.getWorld() instanceof ServerWorld serverWorld && serverWorld.getGameRules().getBoolean(MobAITweaks.MOBS_ARE_OP) && chargingCooldown > 4) chargingCooldown = 4;
    }
    @Inject(method = "tickState", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/mob/MobEntity;setCurrentHand(Lnet/minecraft/util/Hand;)V", shift = At.Shift.AFTER))
    private void fixCrossbowHandCheck(MobEntity entity, LivingEntity target, CallbackInfo ci) {
        entity.stopUsingItem();
        entity.setCurrentHand(entity.getMainHandStack().getItem() instanceof CrossbowItem ? Hand.MAIN_HAND : Hand.OFF_HAND);
    }
}
