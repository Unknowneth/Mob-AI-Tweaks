package com.notunanancyowen.mixin;

import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.FishingBobberEntityRenderer;
import net.minecraft.client.render.entity.state.FishingBobberEntityState;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FishingBobberEntityRenderer.class)
public abstract class FishingBobberEntityRendererMixin extends EntityRenderer<FishingBobberEntity, FishingBobberEntityState> {
    protected FishingBobberEntityRendererMixin(EntityRendererFactory.Context context) {
        super(context);
    }
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/projectile/FishingBobberEntity;Lnet/minecraft/client/render/entity/state/FishingBobberEntityState;F)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/EntityRenderer;updateRenderState(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/entity/state/EntityRenderState;F)V", shift = At.Shift.AFTER), cancellable = true)
    private void renderStateFix(FishingBobberEntity fishingBobberEntity, FishingBobberEntityState fishingBobberEntityState, float f, CallbackInfo ci) {
        if(fishingBobberEntity.getOwner() instanceof PathAwareEntity mob) {
            Vec3d vec3d = getHandPosNotPlayer(mob, f);
            Vec3d vec3d2 = fishingBobberEntity.getLerpedPos(f).add(0.0, 0.25, 0.0);
            fishingBobberEntityState.pos = vec3d.subtract(vec3d2);
            ci.cancel();
        }
    }
    @Inject(method = "shouldRender(Lnet/minecraft/entity/projectile/FishingBobberEntity;Lnet/minecraft/client/render/Frustum;DDD)Z", at = @At("HEAD"), cancellable = true)
    private void forceRender(FishingBobberEntity fishingBobberEntity, Frustum frustum, double d, double e, double f, CallbackInfoReturnable<Boolean> cir) {
        if(fishingBobberEntity.getOwner() instanceof PathAwareEntity) cir.setReturnValue(super.shouldRender(fishingBobberEntity, frustum, d, e, f));
    }
    @Unique private Vec3d getHandPosNotPlayer(PathAwareEntity mob, float tickDelta) {
        int i = mob.getMainArm() == Arm.RIGHT ? 1 : -1;
        ItemStack itemStack = mob.getMainHandStack();
        if (!itemStack.isOf(Items.FISHING_ROD)) i = -i;
        float g = MathHelper.lerp(tickDelta, mob.lastBodyYaw, mob.bodyYaw) * (float) (Math.PI / 180.0);
        double d = MathHelper.sin(g);
        double e = MathHelper.cos(g);
        float h = mob.getScale();
        double j = (double)i * 0.35 * (double)h;
        double k = 0.8 * (double)h;
        float l = mob.isInSneakingPose() ? -0.1875F : 0.0F;
        if(mob instanceof ZombieEntity || (mob instanceof SkeletonEntity skeleton && skeleton.isAttacking())) l += 0.85F;
        return mob.getCameraPosVec(tickDelta).add(-e * j - d * k, (double)l - 0.45 * (double)h, -d * j + e * k);
    }
}
