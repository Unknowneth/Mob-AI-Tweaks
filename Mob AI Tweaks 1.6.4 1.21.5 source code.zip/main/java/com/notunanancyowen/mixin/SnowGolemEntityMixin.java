package com.notunanancyowen.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.goals.SnowGolemAttackGoal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ProjectileAttackGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.passive.GolemEntity;
import net.minecraft.entity.passive.SnowGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.Consumer;

@Mixin(SnowGolemEntity.class)
public abstract class SnowGolemEntityMixin extends GolemEntity {
    @Shadow public abstract boolean hasPumpkin();
    @Shadow public abstract void setHasPumpkin(boolean hasPumpkin);
    protected SnowGolemEntityMixin(EntityType<? extends GolemEntity> type, World world) {
        super(type, world);
    }
    @Inject(method = "initGoals", at = @At("TAIL"))
    private void replaceAI(CallbackInfo ci) {
        if(MobAITweaks.getModConfigValue("snow_golem_rework")) if(goalSelector.getGoals().removeIf(goal -> goal.getGoal() instanceof ProjectileAttackGoal)) goalSelector.add(1, new SnowGolemAttackGoal((SnowGolemEntity)(GolemEntity)this));
    }
    @ModifyReturnValue(method = "createSnowGolemAttributes", at = @At("TAIL"))
    private static DefaultAttributeContainer.Builder addDefense(DefaultAttributeContainer.Builder original) {
        if(!MobAITweaks.getModConfigValue("snow_golem_rework")) return original;
        return original.add(EntityAttributes.ARMOR, MobAITweaks.getModConfigValue("snow_golem_armor_if_it_has_pumpkin", 10));
    }
    @ModifyArg(method = "shootAt", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/projectile/ProjectileEntity;spawn(Lnet/minecraft/entity/projectile/ProjectileEntity;Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/item/ItemStack;Ljava/util/function/Consumer;)Lnet/minecraft/entity/projectile/ProjectileEntity;"), index = 3)
    private Consumer<Entity> becomeMoreAccurateWhenNoMask(Consumer<Entity> beforeSpawn, @Local(argsOnly = true) LivingEntity target) {
        return hasPumpkin() || !MobAITweaks.getModConfigValue("snow_golem_rework") ? beforeSpawn : entity -> {
            double d = target.getX() - this.getX();
            double e = target.getEyeY() - 1.1F;
            double f = target.getZ() - this.getZ();
            double g = Math.sqrt(d * d + f * f) * 0.2F;
            if(entity instanceof SnowballEntity s) s.setVelocity(d, e + g - entity.getY(), f, 1.6F, MobAITweaks.getModConfigValue("snow_golem_accuracy_when_no_pumpkin", 2));
        };
    }
    @Inject(method = "setHasPumpkin", at = @At("TAIL"))
    private void removeDefenseWhenNoPumpkin(boolean hasPumpkin, CallbackInfo ci) {
        if(!MobAITweaks.getModConfigValue("snow_golem_rework")) return;
        var defense = getAttributes().getCustomInstance(EntityAttributes.ARMOR);
        if(defense != null) defense.setBaseValue(hasPumpkin ? MobAITweaks.getModConfigValue("snow_golem_armor_if_it_has_pumpkin", 10) : 0d);
    }
    @Inject(method = "interactMob", at = @At("HEAD"), cancellable = true)
    private void returnPumpkinHead(PlayerEntity player, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
        if(MobAITweaks.getModConfigValue("snow_golem_rework") && MobAITweaks.getModConfigValue("snow_golem_pumpkin_can_be_returned") && player.getStackInHand(hand).isOf(Items.CARVED_PUMPKIN) && !hasPumpkin()) {
            emitGameEvent(GameEvent.SHEAR, player);
            if (!getWorld().isClient) player.getStackInHand(hand).decrementUnlessCreative(1, player);
            setHasPumpkin(true);
            cir.setReturnValue(ActionResult.PASS);
        }
    }
}
