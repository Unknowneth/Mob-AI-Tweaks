package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.brain.task.BreezeShootTask;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(BreezeShootTask.class)
public abstract class BreezeShootTaskMixin {
    @ModifyArg(method = "keepRunning(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/entity/mob/BreezeEntity;J)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/projectile/ProjectileEntity;spawnWithVelocity(Lnet/minecraft/entity/projectile/ProjectileEntity;Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/item/ItemStack;DDDFF)Lnet/minecraft/entity/projectile/ProjectileEntity;"), index = 0)
    private ProjectileEntity windChargeShotgun(ProjectileEntity entity) {
        if((entity.getWorld() instanceof ServerWorld serverWorld && !serverWorld.getGameRules().getBoolean(MobAITweaks.MOBS_ARE_OP)) || entity.getWorld().isClient()) return entity;
        Entity entity1 = entity.getType().create(entity.getWorld(), SpawnReason.MOB_SUMMONED);
        if(entity1 != null) {
            entity1.setVelocity(entity.getVelocity().rotateY((float) Math.PI / 9F));
            entity1.setPosition(entity.getPos());
            entity.getWorld().spawnEntity(entity1);
        }
        Entity entity2 = entity.getType().create(entity.getWorld(), SpawnReason.MOB_SUMMONED);
        if(entity2 != null) {
            entity2.setVelocity(entity.getVelocity().rotateY((float) Math.PI / -9F));
            entity2.setPosition(entity.getPos());
            entity.getWorld().spawnEntity(entity2);
        }
        return entity;
    }
}
