package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.dataholders.SpecialAttacksInterface;
import com.notunanancyowen.goals.RavagerChargeAttackGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.RavagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.raid.RaiderEntity;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.loot.context.LootWorldContext;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;

@Mixin(RavagerEntity.class)
public abstract class RavagerEntityMixin extends RaiderEntity implements SpecialAttacksInterface {
    @Shadow protected abstract void roar();
    @Shadow private int stunTick;
    @Unique private final ServerBossBar bossBar = new ServerBossBar(getDisplayName(), BossBar.Color.RED, BossBar.Style.PROGRESS);
    RavagerEntityMixin(EntityType<? extends RavagerEntity> type, World world) {
        super(type, world);
    }
    @Inject(method = "initGoals", at = @At("HEAD"))
    private void addNewAttacks(CallbackInfo ci) {
        if(MobAITweaks.getModConfigValue("ravager_special_attacks")) goalSelector.add(3, new RavagerChargeAttackGoal(this, MobAITweaks.getModConfigValue("ravager_special_attack_cooldown", 180)));
    }
    @Override protected void updatePostDeath() {
        super.updatePostDeath();
        bossBar.setPercent(0f);
        bossBar.clearPlayers();
        bossBar.setVisible(false);
    }
    @Override protected void mobTick(ServerWorld serverWorld) {
        super.mobTick(serverWorld);
        if(!MobAITweaks.getModConfigValue("ravagers_are_minibosses")) return;
        if(getTarget() instanceof ServerPlayerEntity target && distanceTo(target) < 64) bossBar.addPlayer(target);
        if(getLastAttacker() instanceof ServerPlayerEntity attacker && distanceTo(attacker) < 64) bossBar.addPlayer(attacker);
        for(var player : bossBar.getPlayers()) if(distanceTo(player) >= 64) bossBar.removePlayer(player);
        bossBar.setPercent(getHealth() / getMaxHealth());
        if(hasCustomName()) bossBar.setName(getDisplayName());
    }
    @Override protected void onRemoval(ServerWorld serverWorld, RemovalReason reason) {
        if(MobAITweaks.getModConfigValue("ravagers_are_minibosses")) {
            bossBar.clearPlayers();
            bossBar.setVisible(false);
        }
        if(MobAITweaks.getModConfigValue("bosses_announce_spawn_and_death") && reason == RemovalReason.KILLED) if(getServer() != null && getServer().getPlayerManager() != null) getServer().getPlayerManager().broadcast(Text.translatable("mob-ai-tweaks.boss_defeated", getName().getString()).copy().formatted(Formatting.DARK_PURPLE), false);
        super.onRemoval(serverWorld, reason);
    }
    @Override protected void dropLoot(ServerWorld world, DamageSource damageSource, boolean causedByPlayer) {
        super.dropLoot(world, damageSource, causedByPlayer);
        if(!MobAITweaks.getModConfigValue("enchantments_from_mod") || getWorld().getServer() == null || getWorld().getServer().getReloadableRegistries() == null) return;
        Optional<RegistryKey<LootTable>> optional = this.getLootTableKey();
        if (optional.isPresent()) {
            LootTable lootTable = world.getServer().getReloadableRegistries().getLootTable(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of(MobAITweaks.MOD_ID, "ravager")));
            LootWorldContext.Builder builder = new LootWorldContext.Builder(world)
                    .add(LootContextParameters.THIS_ENTITY, this)
                    .add(LootContextParameters.ORIGIN, this.getPos())
                    .add(LootContextParameters.DAMAGE_SOURCE, damageSource)
                    .addOptional(LootContextParameters.ATTACKING_ENTITY, damageSource.getAttacker())
                    .addOptional(LootContextParameters.DIRECT_ATTACKING_ENTITY, damageSource.getSource());
            PlayerEntity playerEntity = this.getAttackingPlayer();
            if (causedByPlayer && playerEntity != null) {
                builder = builder.add(LootContextParameters.LAST_DAMAGE_PLAYER, playerEntity).luck(playerEntity.getLuck());
            }

            LootWorldContext lootWorldContext = builder.build(LootContextTypes.ENTITY);
            lootTable.generateLoot(lootWorldContext, this.getLootTableSeed(), stack -> this.dropStack(world, stack));
        }
    }
    @SuppressWarnings("all")
    @Override public void forceSpecialAttack() {
        roar();
    }
    @SuppressWarnings("all")
    @Override public void setSpecialCooldown(int i) {
        stunTick = i;
    }
}
