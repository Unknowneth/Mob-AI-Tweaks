package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.dataholders.SpecialAttacksInterface;
import com.notunanancyowen.goals.EvokerCastFireballGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.FleeEntityGoal;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.EvokerEntity;
import net.minecraft.entity.mob.SpellcastingIllagerEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.loot.context.LootWorldContext;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;

@Mixin(EvokerEntity.class)
public abstract class EvokerEntityMixin extends SpellcastingIllagerEntity implements SpecialAttacksInterface {
    @Unique private static final TrackedData<Integer> FIREBALL_COOLDOWN = DataTracker.registerData(EvokerEntityMixin.class, TrackedDataHandlerRegistry.INTEGER);
    EvokerEntityMixin(EntityType<? extends EvokerEntity> type, World world) {
        super(type, world);
    }
    @Inject(method = "initGoals", at = @At("TAIL"))
    private void addNewAttacks(CallbackInfo ci) {
        if(!MobAITweaks.getModConfigValue("evokers_cast_fireball")) return;
        if(goalSelector.getGoals().removeIf(goal -> goal.getGoal() instanceof FleeEntityGoal)) {
            goalSelector.add(2, new FleeEntityGoal<>(this, PlayerEntity.class, 8.0f, 0.4f, 0.8f) {
                @Override public boolean canStart() {
                    return super.canStart() && getSpecialCooldown() >= 0;
                }
                @Override public boolean shouldContinue() {
                    return super.shouldContinue() && getSpecialCooldown() >= 0;
                }
                @Override public boolean canStop() {
                    return super.canStop() || getSpecialCooldown() < 0;
                }
            });
            goalSelector.add(2, new FleeEntityGoal<>(this, IronGolemEntity.class, 10.0f, 0.6f, 1.0f) {
                @Override public boolean canStart() {
                    return super.canStart() && getSpecialCooldown() >= 0;
                }
                @Override public boolean shouldContinue() {
                    return super.shouldContinue() && getSpecialCooldown() >= 0;
                }
                @Override public boolean canStop() {
                    return super.canStop() || getSpecialCooldown() < 0;
                }
            });
        }
        goalSelector.add(1, new EvokerCastFireballGoal(this));
    }
    @Inject(method = "initDataTracker", at = @At("TAIL"))
    private void trackData(DataTracker.Builder builder, CallbackInfo ci) {
        builder.add(FIREBALL_COOLDOWN, MobAITweaks.getModConfigValue("evokers_cast_fireball_cooldown", 20));
    }
    @Override public State getState() {
        if(getSpecialCooldown() < 0) return State.BOW_AND_ARROW;
        return super.getState();
    }
    /*@Inject(method = "mobTick", at = @At("TAIL"))
    private void fireballCooldownTime(CallbackInfo ci) {
        if(!isSpellcasting() && getSpecialCooldown() > 0) setSpecialCooldown(getSpecialCooldown() - 1);
    }*/
    @Override protected void dropLoot(ServerWorld world, DamageSource damageSource, boolean causedByPlayer) {
        super.dropLoot(world, damageSource, causedByPlayer);
        if(!MobAITweaks.getModConfigValue("enchantments_from_mod") || getWorld().getServer() == null || getWorld().getServer().getReloadableRegistries() == null) return;
        Optional<RegistryKey<LootTable>> optional = this.getLootTableKey();
        if (optional.isPresent()) {
            LootTable lootTable = world.getServer().getReloadableRegistries().getLootTable(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of(MobAITweaks.MOD_ID, "evoker")));
            LootWorldContext.Builder builder = new LootWorldContext.Builder(world)
                    .add(LootContextParameters.THIS_ENTITY, this)
                    .add(LootContextParameters.ORIGIN, this.getPos())
                    .add(LootContextParameters.DAMAGE_SOURCE, damageSource)
                    .addOptional(LootContextParameters.ATTACKING_ENTITY, damageSource.getAttacker())
                    .addOptional(LootContextParameters.DIRECT_ATTACKING_ENTITY, damageSource.getSource());
            PlayerEntity playerEntity = this.getAttackingPlayer();
            if (causedByPlayer && playerEntity != null) {
                builder = builder.add(LootContextParameters.LAST_DAMAGE_PLAYER, playerEntity).luck(playerEntity.getLuck());
            }

            LootWorldContext lootWorldContext = builder.build(LootContextTypes.ENTITY);
            lootTable.generateLoot(lootWorldContext, this.getLootTableSeed(), stack -> this.dropStack(world, stack));
        }
    }
    @SuppressWarnings("all")
    @Override public void setSpecialCooldown(int i) {
        getDataTracker().set(FIREBALL_COOLDOWN, i);
    }
    @SuppressWarnings("all")
    @Override public int getSpecialCooldown() {
        return getDataTracker().get(FIREBALL_COOLDOWN);
    }
}
