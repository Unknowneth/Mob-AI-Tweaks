package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.dataholders.SpecialAttacksInterface;
import com.notunanancyowen.goals.SkeletonSpecificGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.StrayEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(StrayEntity.class)
public abstract class StrayEntityMixin extends AbstractSkeletonEntity implements SpecialAttacksInterface {
    @Unique private static final TrackedData<Integer> DODGE_TIME = DataTracker.registerData(StrayEntityMixin.class, TrackedDataHandlerRegistry.INTEGER);
    StrayEntityMixin(EntityType<? extends StrayEntity> type, World world) {
        super(type, world);
    }
    @Inject(method = "createArrowProjectile", at = @At("RETURN"))
    private void arrowFix(ItemStack arrow, float damageModifier, ItemStack shotFrom, CallbackInfoReturnable<PersistentProjectileEntity> cir) {
        cir.getReturnValue().setCritical((!(getControllingVehicle() != null ? getControllingVehicle().isOnGround() : isOnGround()) && fallDistance < 1f && hurtTime == 0) || cir.getReturnValue().isCritical());
    }
    @Override protected void initEquipment(Random random, LocalDifficulty localDifficulty) {
        super.initEquipment(random, localDifficulty);
        if(random.nextInt(8) == 4 && localDifficulty.getLocalDifficulty() > 1.5f) equipStack(EquipmentSlot.MAINHAND, new ItemStack(MobAITweaks.getRandomBow(random), 1));
    }
    @Override protected void initGoals() {
        super.initGoals();
        if(MobAITweaks.getModConfigValue("stray_special_attacks")) goalSelector.add(9, new SkeletonSpecificGoal(this, MobAITweaks.getModConfigValue("stray_special_attack_cooldown", 120)));
    }
    @Override protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(DODGE_TIME, 0);
    }
    @Override public void tickMovement() {
        super.tickMovement();
        int specialCd = getSpecialCooldown();
        if(specialCd != 0) fallDistance = 0F;
        if(specialCd > 0) setSpecialCooldown(specialCd - 1);
        else if(specialCd < 0) setSpecialCooldown(specialCd + 1);
    }
    @Override public boolean isAttacking() {
        return super.isAttacking() && (Math.abs(getSpecialCooldown()) >= 10 || getSpecialCooldown() == 0);
    }
    @SuppressWarnings("all")
    @Override public void setSpecialCooldown(int i) {
        getDataTracker().set(DODGE_TIME, i);
    }
    @SuppressWarnings("all")
    @Override public int getSpecialCooldown() {
        return getDataTracker().get(DODGE_TIME);
    }
}
