package com.notunanancyowen.goals;

import com.notunanancyowen.MobAITweaks;
import net.minecraft.entity.AreaEffectCloudEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;


public class HostileMobRandomlySitDownGoal extends Goal {
    private final HostileEntity mob;
    public HostileMobRandomlySitDownGoal(HostileEntity mob) {
        this.mob = mob;
    }
    @Override public boolean canStart() {
        boolean canSit = mob.getRandom().nextInt(150) == 15 && mob.isOnGround() && mob.getAttacker() == null && mob.getTarget() == null && mob.getVehicle() == null && !mob.getNavigation().isFollowingPath() && !mob.getMoveControl().isMoving() && !mob.getLookControl().isLookingAtSpecificPosition();
        if(canSit) { //heaviest check so its the last one checked
            var id = Registries.ENTITY_TYPE.getId(mob.getType());
            if(MobAITweaks.hostilesThatCannotSit.contains(id.getNamespace() + ":" + id.getPath())) return false;
        }
        return canSit;
    }
    @Override public boolean shouldContinue() {
        return false;
    }
    @Override public void start() {
        AreaEffectCloudEntity comfySpot = new AreaEffectCloudEntity(mob.getWorld(), mob.getX(), mob.getY() - 0.4d, mob.getZ());
        comfySpot.setOwner(mob);
        comfySpot.addCommandTag(MobAITweaks.MOD_ID + ":" + mob.getName().getString() + "'s seat");
        comfySpot.setDuration(mob.getRandom().nextBetween(200, 500));
        comfySpot.setRadius(0);
        comfySpot.setParticleType(new BlockStateParticleEffect(ParticleTypes.BLOCK, mob.getSteppingBlockState()));
        mob.getWorld().spawnEntity(comfySpot);
        mob.startRiding(comfySpot, true);
    }
}
