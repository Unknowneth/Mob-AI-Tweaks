package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.goals.HostileMobRandomlySitDownGoal;
import com.notunanancyowen.goals.RangedGunAttackGoal;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.RangedAttackMob;
import net.minecraft.entity.ai.goal.BowAttackGoal;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.ProjectileAttackGoal;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.RangedWeaponItem;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;

@Mixin(value = AbstractSkeletonEntity.class, priority = 1001)
public abstract class AbstractSkeletonEntityMixin extends HostileEntity implements RangedAttackMob {
    @Shadow protected abstract int getHardAttackInterval();
    @Shadow protected abstract int getRegularAttackInterval();
    @Shadow protected abstract PersistentProjectileEntity createArrowProjectile(ItemStack arrow, float damageModifier, @Nullable ItemStack shotFrom);
    @Unique private static final TrackedData<Boolean> BABY = DataTracker.registerData(AbstractSkeletonEntityMixin.class, TrackedDataHandlerRegistry.BOOLEAN);
    @Unique private boolean cantStrafe() {
        if(!MobAITweaks.getModConfigValue("skeleton_sniper_AI") && !isBaby()) return false;
        if(getWorld().getGameRules().getBoolean(MobAITweaks.MOBS_ARE_OP)) return getControllingVehicle() == null && age / 100 % 2 == 0; //switch attack types every 5 seconds
        return (isBaby() || !getWorld().isSkyVisible(getBlockPos()) || getWorld().isDay()) && getControllingVehicle() == null;
    }
    AbstractSkeletonEntityMixin(EntityType<? extends AbstractSkeletonEntity> entityType, World world) {
        super(entityType, world);
    }
    @Override protected void tickHandSwing() {
        super.tickHandSwing();
        if(isUsingItem() && !handSwinging) handSwingProgress = 1f;
    }
    @Override public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("IsBaby", isBaby());
    }
    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void readNBTData(NbtCompound nbt, CallbackInfo ci) {
        setBaby(nbt.getBoolean("IsBaby"));
    }
    @Inject(method = "initialize", at = @At("TAIL"))
    private void onSpawned(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason spawnReason, EntityData entityData, CallbackInfoReturnable<EntityData> cir) {
        if(MobAITweaks.getModConfigValue("skeleton_babies") && world.getRandom().nextInt(10) == 5) setBaby(true);
    }
    @Override protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(BABY, false);
        if(FabricLoader.getInstance().isModLoaded("frycmobvariants")) try {
            builder.add(new TrackedData<>(BABY.id() - 1, TrackedDataHandlerRegistry.BOOLEAN), false);
        }
        catch(Throwable ignore) {
        }
        super.initDataTracker(builder);
    }
    @Override public void onTrackedDataSet(TrackedData<?> data) {
        super.onTrackedDataSet(data);
        if(data.equals(BABY)) calculateDimensions();
    }
    @Override public void setBaby(boolean baby) {
        this.getDataTracker().set(BABY, baby);
    }
    @Override public boolean isBaby() {
        return this.getDataTracker().get(BABY) && MobAITweaks.getModConfigValue("skeleton_babies");
    }
    @Inject(method = "tickMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/mob/HostileEntity;tickMovement()V"), cancellable = true)
    private void disableAIWhenSitting(CallbackInfo ci) {
        if(getVehicle() instanceof AreaEffectCloudEntity aoe && aoe.getOwner() != null && aoe.getOwner().getId() == getId() && aoe.getCommandTags().contains(MobAITweaks.MOD_ID + ":" + getName().getString() + "'s seat")) {
            if(MobAITweaks.getModConfigValue("hostile_mobs_sitting_can_be_startled")) targetSelector.getGoals().forEach(g -> {
                if(g.canStart()) g.start();
            });
            if(aoe.age > 60) {
                setPitch(60F);
                if(age % 10 == 0) heal(1F);
            }
            if(aoe.age == aoe.getDuration() + aoe.getWaitTime() - 1) {
                stopRiding();
                refreshPositionAndAngles(getX(), aoe.getBlockY() + 1, getZ(), getYaw(), 0F);
            }
            else if(hurtTime > 0 || (getTarget() != null && !getTarget().isSneaking() && (getTarget().getVelocity().getX() != 0F || getTarget().getVelocity().getZ() != 0F)) || getAttacker() != null || isDead() || getWorld().getBlockState(getBlockPos().down()).isAir() || !getWorld().getBlockState(getBlockPos().up()).isAir()) {
                if(getAttacker() != null && !getAttacker().isPlayer()) setTarget(getAttacker());
                stopRiding();
                refreshPositionAndAngles(getX(), aoe.getBlockY() + 1, getZ(), getYaw(), 0F);
                aoe.discard();
            }
            ci.cancel();
        }
    }
    @Inject(method = "initGoals", at = @At("HEAD"))
    private void addNewAttacks(CallbackInfo ci) {
        goalSelector.add(4, new MeleeAttackGoal(this, 1.2, false) {
            private boolean holdingGun() {
                return getMainHandStack().getItem().getClass().getSimpleName().contains("Gun") || getMainHandStack().getItem().getClass().getSuperclass().getSimpleName().contains("Gun") || getOffHandStack().getItem().getClass().getSimpleName().contains("Gun") || getOffHandStack().getItem().getClass().getSuperclass().getSimpleName().contains("Gun");
            }
            @Override public boolean canStart() {
                return !(getMainHandStack().getItem() instanceof BowItem) && !(getOffHandStack().getItem() instanceof BowItem) && !holdingGun() && getTarget() != null;
            }
            @Override public boolean shouldContinue() {
                return super.shouldContinue() && (forwardSpeed >= 0f || !holdingGun());
            }
            @Override public boolean canStop() {
                return getMainHandStack().getItem() instanceof BowItem || getOffHandStack().getItem() instanceof BowItem || getTarget() == null || forwardSpeed < 0f || holdingGun();
            }
            @Override public void start() {
                setAttacking(true);
                super.start();
            }
            @Override public void stop() {
                setAttacking(false);
                setSprinting(false);
                super.stop();
            }
            @Override public void tick() {
                super.tick();
                setSprinting(mob.getNavigation().isFollowingPath());
            }
        });
        goalSelector.add(4, new BowAttackGoal<>((AbstractSkeletonEntity)(HostileEntity)this, 1.0, getRegularAttackInterval(), 15f) {
            @Override public boolean canStart() {
                return super.canStart() && !cantStrafe();
            }
            @Override public boolean shouldContinue() {
                return super.shouldContinue() || (isUsingItem() && getTarget() != null);
            }
            @Override public boolean canStop() {
                return super.canStop() || cantStrafe();
            }
            @Override public void start() {
                int i = getHardAttackInterval();
                if (getWorld().getDifficulty().getId() == 2) i = (getRegularAttackInterval() + i) / 2;
                else if (getWorld().getDifficulty().getId() < 2) i = getRegularAttackInterval();
                setAttackInterval(i);
                super.start();
            }
            @Override public void stop() {
                boolean wasUsingItem = isUsingItem() && cantStrafe();
                super.stop();
                if(wasUsingItem) setCurrentHand(getMainHandStack().getItem() instanceof BowItem ? Hand.MAIN_HAND : Hand.OFF_HAND);
                if(cantStrafe() && getTarget() != null) setAttacking(true);
            }
        });
        goalSelector.add(4, new ProjectileAttackGoal(this, 1.25, getHardAttackInterval() + 20, getRegularAttackInterval() + 20, 15f) {
            @Override public boolean canStart() {
                return cantStrafe() && (getMainHandStack().getItem() instanceof BowItem || getOffHandStack().getItem() instanceof BowItem) && super.canStart();
            }
            @Override public boolean shouldContinue() {
                return super.shouldContinue();
            }
            @Override public boolean canStop() {
                return !cantStrafe() || (!(getMainHandStack().getItem() instanceof BowItem) && !(getOffHandStack().getItem() instanceof BowItem)) || super.canStop();
            }
            @Override public void start() {
                if(cantStrafe() && (handSwinging || handSwingProgress > 0F) && !isUsingItem()) setCurrentHand(getMainHandStack().getItem() instanceof BowItem ? Hand.MAIN_HAND : Hand.OFF_HAND);
                super.start();
            }
            @Override public void stop() {
                super.stop();
                setAttacking(false);
                if(cantStrafe()) stopUsingItem();
            }
        });
        if(MobAITweaks.getModConfigValue("ranged_mobs_use_guns")) goalSelector.add(4, new RangedGunAttackGoal(this));
        if(FabricLoader.getInstance().isModLoaded("musketmod")) goalSelector.add(0, new Goal() {
            @Override public boolean canStart() {
                return getTarget() != null && (getMainHandStack().getItem().getClass().getSimpleName().contains("GunItem") || getOffHandStack().getItem().getClass().getSimpleName().contains("GunItem") || getMainHandStack().getItem().getClass().getSuperclass().getSimpleName().contains("GunItem") || getOffHandStack().getItem().getClass().getSuperclass().getSimpleName().contains("GunItem"));
            }
            @Override public void tick() {
                if(!isUsingItem() && !handSwinging && getActiveHand() != null && !getWorld().getOtherEntities(AbstractSkeletonEntityMixin.this, getBoundingBox(), e -> e.getClass().getSimpleName().contains("Bullet")).isEmpty()) swingHand(getActiveHand());
                if(getTarget() == null) return;
                getLookControl().lookAt(getTarget(), 60F, 60F);
                lookAtEntity(getTarget(), 60F, 60F);
                float skeletonSpeedMultiplier = MobAITweaks.getModConfigValue("skeleton_strafe_speed_buff") ? getWorld().getGameRules().getBoolean(MobAITweaks.MOBS_ARE_OP) ? 2F : getWorld().getDifficulty().getId() > 1 ? 1.5F : 1F : 1F;
                getMoveControl().strafeTo(Math.signum(forwardSpeed) * skeletonSpeedMultiplier, Math.signum(sidewaysSpeed) * skeletonSpeedMultiplier);
            }
        });
        if(MobAITweaks.getModConfigValue("hostile_mobs_can_sit")) goalSelector.add(10, new HostileMobRandomlySitDownGoal(this));
    }
    @Inject(method = "shootAt", at = @At("HEAD"), cancellable = true)
    private void shootAtFix(LivingEntity target, float pullProgress, CallbackInfo ci) {
        ItemStack bow = getStackInHand(ProjectileUtil.getHandPossiblyHolding(this, (getMainHandStack().getItem() instanceof BowItem bowItem ? bowItem : getOffHandStack().getItem() instanceof BowItem bowItem2 ? bowItem2 : ItemStack.EMPTY.getItem())));
        PersistentProjectileEntity persistentProjectileEntity = createArrowProjectile(getProjectileType(bow), pullProgress, bow);
        if(!bow.isEmpty()) bow.damage(1, this, getPreferredEquipmentSlot(bow));
        double x = target.getX() - getX();
        double y = target.getBodyY(1F / 3F) - persistentProjectileEntity.getY();
        double z = target.getZ() - getZ();
        double v = Math.sqrt(x * x + z * z);
        persistentProjectileEntity.setPosition(persistentProjectileEntity.getPos().subtract(0d, getScale() * getScaleFactor() / 4F, 0d).add(getRotationVector()));
        persistentProjectileEntity.setVelocity(x, y + v * 0.2F, z, 1.6F, (float)(14 - getWorld().getDifficulty().getId() * 4));
        if(cantStrafe() && !isBaby()) persistentProjectileEntity.setCritical(true);
        playSound(SoundEvents.ENTITY_SKELETON_SHOOT, 1.0F, 1.0F / (getRandom().nextFloat() * 0.4F + 0.8F));
        getWorld().spawnEntity(persistentProjectileEntity);
        ci.cancel();
    }
    @Inject(method = "updateAttackType", at = @At("HEAD"), cancellable = true)
    private void fixWeaponTypeCheck(CallbackInfo ci) {
        ci.cancel();
    }
    @Override public boolean canUseRangedWeapon(RangedWeaponItem weapon) {
        return weapon instanceof BowItem;
    }
}
