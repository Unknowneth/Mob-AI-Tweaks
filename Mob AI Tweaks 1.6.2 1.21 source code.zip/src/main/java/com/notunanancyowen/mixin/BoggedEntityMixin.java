package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.dataholders.SpecialAttacksInterface;
import com.notunanancyowen.goals.SkeletonSpecificGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.BoggedEntity;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BoggedEntity.class)
public abstract class BoggedEntityMixin extends AbstractSkeletonEntity implements SpecialAttacksInterface {
    @Unique private static final TrackedData<Integer> DODGE_TIME = DataTracker.registerData(BoggedEntityMixin.class, TrackedDataHandlerRegistry.INTEGER);
    BoggedEntityMixin(EntityType<? extends BoggedEntity> type, World world) {
        super(type, world);
    }
    @Override protected void initGoals() {
        super.initGoals();
        if(MobAITweaks.getModConfigValue("bogged_special_attacks")) goalSelector.add(9, new SkeletonSpecificGoal(this, MobAITweaks.getModConfigValue("bogged_special_attack_cooldown", 120)));
    }
    @Override protected void initEquipment(Random random, LocalDifficulty localDifficulty) {
        super.initEquipment(random, localDifficulty);
        if(random.nextInt(8) == 4 && localDifficulty.getLocalDifficulty() > 1f) equipStack(EquipmentSlot.MAINHAND, MobAITweaks.getRandomBow(random).getDefaultStack());
    }
    @Inject(method = "initDataTracker", at = @At("TAIL"))
    private void trackData(DataTracker.Builder builder, CallbackInfo ci) {
        builder.add(DODGE_TIME, 0);
    }
    @Override public void tickMovement() {
        super.tickMovement();
        int specialCd = getSpecialCooldown();
        if(specialCd != 0) fallDistance = 0F;
        if(specialCd > 0) setSpecialCooldown(specialCd - 1);
        else if(specialCd < 0) setSpecialCooldown(specialCd + 1);
    }
    @Override public boolean damage(DamageSource source, float amount) {
        if(getSpecialCooldown() > 0) amount = 0F;
        return super.damage(source, amount);
    }
    @Override public boolean isSprinting() {
        return super.isSprinting() || getSpecialCooldown() != 0;
    }
    @SuppressWarnings("all")
    @Override public void setSpecialCooldown(int i) {
        getDataTracker().set(DODGE_TIME, i);
    }
    @SuppressWarnings("all")
    @Override public int getSpecialCooldown() {
        return getDataTracker().get(DODGE_TIME);
    }
}
