package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.dataholders.SpecialAttacksInterface;
import com.notunanancyowen.goals.RavagerChargeAttackGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.RavagerEntity;
import net.minecraft.entity.raid.RaiderEntity;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.context.LootContextParameterSet;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(RavagerEntity.class)
public abstract class RavagerEntityMixin extends RaiderEntity implements SpecialAttacksInterface {
    @Shadow protected abstract void roar();
    @Shadow private int stunTick;
    @Unique private final ServerBossBar bossBar = new ServerBossBar(getDisplayName(), BossBar.Color.RED, BossBar.Style.PROGRESS);
    RavagerEntityMixin(EntityType<? extends RavagerEntity> type, World world) {
        super(type, world);
    }
    @Inject(method = "initGoals", at = @At("HEAD"))
    private void addNewAttacks(CallbackInfo ci) {
        if(MobAITweaks.getModConfigValue("ravager_special_attacks")) goalSelector.add(3, new RavagerChargeAttackGoal(this, MobAITweaks.getModConfigValue("ravager_special_attack_cooldown", 180)));
    }
    @Override protected void updatePostDeath() {
        super.updatePostDeath();
        bossBar.setPercent(0f);
        bossBar.clearPlayers();
        bossBar.setVisible(false);
    }
    @Override protected void mobTick() {
        super.mobTick();
        if(!MobAITweaks.getModConfigValue("ravagers_are_minibosses")) return;
        if(getTarget() instanceof ServerPlayerEntity target && distanceTo(target) < 64) bossBar.addPlayer(target);
        if(getLastAttacker() instanceof ServerPlayerEntity attacker && distanceTo(attacker) < 64) bossBar.addPlayer(attacker);
        for(var player : bossBar.getPlayers()) if(distanceTo(player) >= 64) bossBar.removePlayer(player);
        bossBar.setPercent(getHealth() / getMaxHealth());
        if(hasCustomName()) bossBar.setName(getDisplayName());
    }
    @Override protected void onRemoval(RemovalReason reason) {
        if(MobAITweaks.getModConfigValue("ravagers_are_minibosses")) {
            bossBar.clearPlayers();
            bossBar.setVisible(false);
        }
        if(MobAITweaks.getModConfigValue("bosses_announce_spawn_and_death") && reason == RemovalReason.KILLED) if(getServer() != null && getServer().getPlayerManager() != null) getServer().getPlayerManager().broadcast(Text.translatable("mob-ai-tweaks.boss_defeated", getName().getString()).copy().formatted(Formatting.DARK_PURPLE), false);
        super.onRemoval(reason);
    }
    @Override protected void dropLoot(DamageSource damageSource, boolean causedByPlayer) {
        super.dropLoot(damageSource, causedByPlayer);
        if(!MobAITweaks.getModConfigValue("enchantments_from_mod") || getWorld().getServer() == null || getWorld().getServer().getReloadableRegistries() == null) return;
        LootTable lootTable = getWorld().getServer().getReloadableRegistries().getLootTable(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of(MobAITweaks.MOD_ID, "ravager")));
        LootContextParameterSet.Builder builder = new LootContextParameterSet.Builder((ServerWorld)getWorld()).add(LootContextParameters.THIS_ENTITY, this).add(LootContextParameters.ORIGIN, getPos()).add(LootContextParameters.DAMAGE_SOURCE, damageSource).addOptional(LootContextParameters.ATTACKING_ENTITY, damageSource.getAttacker()).addOptional(LootContextParameters.DIRECT_ATTACKING_ENTITY, damageSource.getSource());
        if(causedByPlayer && attackingPlayer != null) builder = builder.add(LootContextParameters.LAST_DAMAGE_PLAYER, attackingPlayer).luck(attackingPlayer.getLuck());
        LootContextParameterSet lootContextParameterSet = builder.build(LootContextTypes.ENTITY);
        lootTable.generateLoot(lootContextParameterSet, getLootTableSeed(), this::dropStack);
    }
    @SuppressWarnings("all")
    @Override public void forceSpecialAttack() {
        roar();
    }
    @SuppressWarnings("all")
    @Override public void setSpecialCooldown(int i) {
        stunTick = i;
    }
}
