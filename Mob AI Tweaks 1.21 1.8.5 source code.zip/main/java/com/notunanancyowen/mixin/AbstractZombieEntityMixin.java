package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.goals.HostileMobRandomlySitDownGoal;
import net.minecraft.block.entity.BannerPattern;
import net.minecraft.block.entity.BannerPatterns;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.BannerPatternsComponent;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.*;
import net.minecraft.item.DyeItem;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ZombieEntity.class)
public abstract class AbstractZombieEntityMixin extends HostileEntity {
    @Shadow public abstract boolean isBaby();
    @Shadow @Final private static Identifier LEADER_ZOMBIE_BONUS_MODIFIER_ID;
    @Shadow protected abstract boolean burnsInDaylight();
    AbstractZombieEntityMixin(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
    }
    @Inject(method = "initGoals", at = @At("TAIL"))
    private void addNewAttacks(CallbackInfo ci) {
        if(MobAITweaks.getModConfigValue("hostile_mobs_can_sit")) goalSelector.add(10, new HostileMobRandomlySitDownGoal(this));
        if(MobAITweaks.getModConfigValue("illagers_and_normal_zombies_fight")) targetSelector.add(!MobAITweaks.getModConfigValue("illagers_and_zombies_prioritize_player") ? 2 : 3, new ActiveTargetGoal<>(this, IllagerEntity.class, true, l -> !getType().isIn(MobAITweaks.ZOMBIES_NOT_TARGETABLE_BY_ILLAGERS)));
    }
    @Inject(method = "tickMovement", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/mob/HostileEntity;tickMovement()V"), cancellable = true)
    private void disableAIWhenSitting(CallbackInfo ci) {
        if(getVehicle() instanceof AreaEffectCloudEntity aoe && aoe.getOwner() != null && aoe.getOwner().getId() == getId() && aoe.getCommandTags().contains(MobAITweaks.MOD_ID + ":" + getName().getString() + "'s seat")) {
            if(aoe.age > 60) {
                setPitch(60F);
                if(age % 10 == 0) heal(1F);
            }
            else if(aoe.age > 40) setPitch((aoe.age - 40) * 3);
            if(aoe.age == aoe.getDuration() + aoe.getWaitTime() - 1) {
                stopRiding();
                refreshPositionAndAngles(getX(), aoe.getBlockY() + 1, getZ(), getYaw(), 0F);
            }
            else if(hurtTime > 0 || (getTarget() != null && !getTarget().isSneaking() && (getTarget().getVelocity().getX() != 0F || getTarget().getVelocity().getZ() != 0F)) || getAttacker() != null || isDead() || getWorld().getBlockState(getBlockPos().down()).isAir() || !getWorld().getBlockState(getBlockPos().up()).isAir()) {
                if(getAttacker() != null && canTarget(getAttacker())) setTarget(getAttacker());
                stopRiding();
                refreshPositionAndAngles(getX(), aoe.getBlockY() + 1, getZ(), getYaw(), 0F);
                aoe.discard();
            }
            ci.cancel();
        }
    }
    @Inject(method = "initialize", at = @At("TAIL"))
    private void onSpawned(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason spawnReason, EntityData entityData, CallbackInfoReturnable<EntityData> cir) {
        if(spawnReason == SpawnReason.NATURAL && MobAITweaks.getModConfigValue("hostile_mobs_spawn_with_effects_chance", 10) > 0 && world.getDifficulty().getId() == 3 && getRandom().nextFloat() < (MobAITweaks.getModConfigValue("hostile_mobs_spawn_with_effects_chance", 10) * 0.01F) * difficulty.getClampedLocalDifficulty()) switch(getRandom().nextInt(getWorld().getGameRules().getBoolean(MobAITweaks.MOBS_ARE_OP) ? 5 : 4)) {
            case 2 -> addStatusEffect(new StatusEffectInstance(burnsInDaylight() ? StatusEffects.FIRE_RESISTANCE : StatusEffects.SPEED, -1));
            case 0 -> addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, -1));
            case 4 -> addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, -1));
            case 1 -> addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, -1));
            default -> addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, -1));
        }
        if(MobAITweaks.getModConfigValue("zombie_dads_from_bedrock") && !isBaby() && world.getRandom().nextInt(100) < MobAITweaks.getModConfigValue("zombie_dads_spawn_chance", 1) && spawnReason == SpawnReason.NATURAL && difficulty.getLocalDifficulty() > 1.5F) if(getType() == EntityType.ZOMBIE) {
            if(world.getRandom().nextBoolean()) {
                ZombieEntity zombie = EntityType.ZOMBIE.create(getWorld());
                if(zombie == null) return;
                zombie.refreshPositionAndAngles(getPos(), getYaw(), 0F);
                zombie.setBaby(true);
                zombie.initialize(world, difficulty, SpawnReason.JOCKEY, null);
                world.spawnEntity(zombie);
                zombie.startRiding(this, true);
            }
            else {
                SkeletonEntity skeleton = EntityType.SKELETON.create(getWorld());
                if(skeleton == null) return;
                skeleton.refreshPositionAndAngles(getPos(), getYaw(), 0F);
                skeleton.setBaby(true);
                skeleton.initialize(world, difficulty, SpawnReason.JOCKEY, null);
                skeleton.tryEquip(MobAITweaks.getRandomBow(world.getRandom()).getDefaultStack());
                world.spawnEntity(skeleton);
                skeleton.startRiding(this, true);
            }
        }
        else if(getType() == EntityType.HUSK) {
            if(world.getRandom().nextBoolean()) {
                HuskEntity zombie = EntityType.HUSK.create(getWorld());
                if(zombie == null) return;
                zombie.refreshPositionAndAngles(getPos(), getYaw(), 0F);
                zombie.setBaby(true);
                zombie.initialize(world, difficulty, SpawnReason.JOCKEY, null);
                world.spawnEntity(zombie);
                zombie.startRiding(this, true);
            }
            else {
                BoggedEntity skeleton = EntityType.BOGGED.create(getWorld());
                if(skeleton == null) return;
                skeleton.refreshPositionAndAngles(getPos(), getYaw(), 0F);
                skeleton.setBaby(true);
                skeleton.initialize(world, difficulty, SpawnReason.JOCKEY, null);
                skeleton.tryEquip(MobAITweaks.getRandomBow(world.getRandom()).getDefaultStack());
                world.spawnEntity(skeleton);
                skeleton.startRiding(this, true);
            }
        }
        else if(getType() == EntityType.ZOMBIE_VILLAGER) {
            ZombieVillagerEntity zombie = EntityType.ZOMBIE_VILLAGER.create(getWorld());
            if(zombie == null) return;
            zombie.refreshPositionAndAngles(getPos(), getYaw(), 0F);
            zombie.setBaby(true);
            zombie.initialize(world, difficulty, SpawnReason.JOCKEY, null);
            zombie.tryEquip(MobAITweaks.getRandomCrossbow(world.getRandom()).getDefaultStack());
            world.spawnEntity(zombie);
            zombie.startRiding(this, true);
        }
        else if(getType() == EntityType.ZOMBIFIED_PIGLIN) {
            ZombifiedPiglinEntity zombie = EntityType.ZOMBIFIED_PIGLIN.create(getWorld());
            if(zombie == null) return;
            zombie.refreshPositionAndAngles(getPos(), getYaw(), 0F);
            zombie.setBaby(true);
            zombie.initialize(world, difficulty, SpawnReason.JOCKEY, null);
            zombie.tryEquip(MobAITweaks.getRandomCrossbow(world.getRandom()).getDefaultStack());
            world.spawnEntity(zombie);
            zombie.startRiding(this, true);
        }
        if(MobAITweaks.getModConfigValue("zombie_leader_rework") && getType() == EntityType.ZOMBIE && getAttributes().hasModifierForAttribute(EntityAttributes.ZOMBIE_SPAWN_REINFORCEMENTS, LEADER_ZOMBIE_BONUS_MODIFIER_ID)) {
            var whateverThisIs = Items.CYAN_BANNER.getDefaultStack();
            whateverThisIs.apply(DataComponentTypes.BANNER_PATTERNS, BannerPatternsComponent.DEFAULT, patterns -> new BannerPatternsComponent.Builder().addAll(patterns).add(RegistryEntry.of((BannerPattern)world.getRegistryManager().get(RegistryKey.ofRegistry(BannerPatterns.GRADIENT_UP.getRegistry())).get(BannerPatterns.GRADIENT_UP.getValue())), ((DyeItem)Items.LIGHT_BLUE_DYE).getColor()).build());
            whateverThisIs.apply(DataComponentTypes.BANNER_PATTERNS, BannerPatternsComponent.DEFAULT, patterns -> new BannerPatternsComponent.Builder().addAll(patterns).add(RegistryEntry.of((BannerPattern)world.getRegistryManager().get(RegistryKey.ofRegistry(BannerPatterns.CURLY_BORDER.getRegistry())).get(BannerPatterns.CURLY_BORDER.getValue())), ((DyeItem)Items.BLUE_DYE).getColor()).build());
            whateverThisIs.apply(DataComponentTypes.BANNER_PATTERNS, BannerPatternsComponent.DEFAULT, patterns -> new BannerPatternsComponent.Builder().addAll(patterns).add(RegistryEntry.of((BannerPattern)world.getRegistryManager().get(RegistryKey.ofRegistry(BannerPatterns.RHOMBUS.getRegistry())).get(BannerPatterns.RHOMBUS.getValue())), ((DyeItem)Items.YELLOW_DYE).getColor()).build());
            whateverThisIs.apply(DataComponentTypes.BANNER_PATTERNS, BannerPatternsComponent.DEFAULT, patterns -> new BannerPatternsComponent.Builder().addAll(patterns).add(RegistryEntry.of((BannerPattern)world.getRegistryManager().get(RegistryKey.ofRegistry(BannerPatterns.BORDER.getRegistry())).get(BannerPatterns.BORDER.getValue())), ((DyeItem)Items.GREEN_DYE).getColor()).build());
            whateverThisIs.apply(DataComponentTypes.BANNER_PATTERNS, BannerPatternsComponent.DEFAULT, patterns -> new BannerPatternsComponent.Builder().addAll(patterns).add(RegistryEntry.of((BannerPattern)world.getRegistryManager().get(RegistryKey.ofRegistry(BannerPatterns.FLOWER.getRegistry())).get(BannerPatterns.FLOWER.getValue())), ((DyeItem)Items.PINK_DYE).getColor()).build());
            whateverThisIs.apply(DataComponentTypes.BANNER_PATTERNS, BannerPatternsComponent.DEFAULT, patterns -> new BannerPatternsComponent.Builder().addAll(patterns).add(RegistryEntry.of((BannerPattern)world.getRegistryManager().get(RegistryKey.ofRegistry(BannerPatterns.SKULL.getRegistry())).get(BannerPatterns.SKULL.getValue())), ((DyeItem)Items.LIME_DYE).getColor()).build());
            whateverThisIs.apply(DataComponentTypes.ITEM_NAME, Text.translatable("mob-ai-tweaks.zombie_leader_banner"), Text::copy);
            equipStack(EquipmentSlot.HEAD, whateverThisIs);
            setEquipmentDropChance(EquipmentSlot.HEAD, 100.0F);
            ZombieHorseEntity zombieHorse = EntityType.ZOMBIE_HORSE.create(getWorld());
            if(zombieHorse == null) return;
            zombieHorse.refreshPositionAndAngles(getPos(), getYaw(), 0F);
            zombieHorse.initialize(world, difficulty, SpawnReason.JOCKEY, null);
            zombieHorse.setBaby(false);
            zombieHorse.setTame(true);
            var attribution = zombieHorse.getAttributes().getCustomInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED);
            if(attribution != null) attribution.setBaseValue(0.5d);
            world.spawnEntity(zombieHorse);
            startRiding(zombieHorse, true);
        }
    }
    @Override protected void updatePassengerPosition(Entity passenger, Entity.PositionUpdater positionUpdater) {
        super.updatePassengerPosition(passenger, positionUpdater);
        if(passenger instanceof HostileEntity h && h.isBaby()) {
            var v = getEyePos().subtract(getRotationVector(0f, getBodyYaw()).multiply(0.25));
            positionUpdater.accept(passenger, v.getX(), v.getY() - 0.5, v.getZ());
            h.bodyYaw = getBodyYaw();
            h.setAttacking(true);
        }
    }
}
