package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.goals.SkeletonSpecificGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.WitherSkeletonEntity;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WitherSkeletonEntity.class)
public abstract class WitherSkeletonEntityMixin extends AbstractSkeletonEntity {
    WitherSkeletonEntityMixin(EntityType<? extends WitherSkeletonEntity> type, World world) {
        super(type, world);
    }
    @Inject(method = "initGoals", at = @At("TAIL"))
    private void addNewAttacks(CallbackInfo ci) {
        if(MobAITweaks.getModConfigValue("wither_skeleton_special_attacks")) goalSelector.add(9, new SkeletonSpecificGoal(this,  MobAITweaks.getModConfigValue("wither_skeleton_special_attack_cooldown", 200)));
    }
    @SuppressWarnings("all")
    @Inject(method = "initEquipment", at = @At("HEAD"), cancellable = true)
    private void equipWithOtherGear(Random random, LocalDifficulty localDifficulty, CallbackInfo ci) {
        if(MobAITweaks.getModConfigValue("skeleton_switch_to_melee_range", 0) == 0 && random.nextInt(100) < MobAITweaks.getModConfigValue("wither_skeletons_with_bows_chance", 10) && localDifficulty.getLocalDifficulty() > 2.5F) {
            tryEquip(MobAITweaks.getRandomBow(random).getDefaultStack());
            enchantMainHandItem(getServer().getWorld(getWorld().getRegistryKey()), random, localDifficulty);
            ci.cancel();
        }
    }
}
