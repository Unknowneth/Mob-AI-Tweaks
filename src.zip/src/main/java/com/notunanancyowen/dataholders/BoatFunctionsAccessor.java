package com.notunanancyowen.dataholders;

public interface BoatFunctionsAccessor {
    void forceUpdatePaddles(boolean left, boolean right);
}
