package com.notunanancyowen.dataholders;

import net.minecraft.util.math.BlockPos;

public interface WardenAttacksInterface {
    void setBell(BlockPos blockPos);
}
