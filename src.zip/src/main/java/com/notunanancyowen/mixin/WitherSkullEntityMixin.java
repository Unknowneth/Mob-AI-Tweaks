package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.projectile.ExplosiveProjectileEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.entity.projectile.WitherSkullEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WitherSkullEntity.class)
public abstract class WitherSkullEntityMixin extends ExplosiveProjectileEntity {
    @Shadow public abstract boolean isCharged();
    @Shadow protected abstract float getDrag();
    @Unique private boolean spawned = false;
    @Unique private boolean canBluesHome = true;
    WitherSkullEntityMixin(EntityType<? extends WitherSkullEntity> type, World world) {
        super(type, world);
    }
    @Override public void tick() {
        if(!spawned) {
            if(getWorld().isClient()) {
                for (int i = 0; i < 12; i++) getWorld().addParticle(isCharged() && i > 6 ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.SMOKE, getPos().getX(), getPos().getY(), getPos().getZ(), getRandom().nextBetween(-100, 100) * 0.002d, getRandom().nextBetween(-100, 100) * 0.002d, getRandom().nextBetween(-100, 100) * 0.002d);
                if (isCharged()) getWorld().addParticle(ParticleTypes.FLASH, getPos().getX(), getPos().getY(), getPos().getZ(), 0d, 0d, 0d);
            }
            ProjectileUtil.setRotationFromVelocity(this, 1.0F);
            spawned = true;
            canBluesHome = MobAITweaks.getModConfigValue("wither_rework");
        }
        super.tick();
        if(isCharged() && canBluesHome) {
            if(getOwner() instanceof HostileEntity shooter && shooter.getTarget() instanceof LivingEntity target && (target.isBlocking() || target.isOnGround() || distanceTo(target) > 2) && target.isAlive() && spawned) {
                setVelocity(getVelocity().multiply(getDrag()));
                addVelocity(target.getEyePos().subtract(getPos()).normalize().multiply(0.17d));
            }
            if(getRandom().nextBoolean() && getWorld().isClient()) getWorld().addParticle(ParticleTypes.SOUL_FIRE_FLAME, getPos().getX(), getPos().getY(), getPos().getZ(), getRandom().nextBetween(-100, 100) * 0.001d, getRandom().nextBetween(-100, 100) * 0.001d + 0.02d, getRandom().nextBetween(-100, 100) * 0.001d);
        }
    }
    @Inject(method = "onEntityHit", at = @At("TAIL"))
    private void healWither(EntityHitResult entityHitResult, CallbackInfo ci) {
        if(getOwner() instanceof WitherEntity wither) wither.heal(1);
    }
}
