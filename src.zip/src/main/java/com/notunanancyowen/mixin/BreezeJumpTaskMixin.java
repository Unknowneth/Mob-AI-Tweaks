package com.notunanancyowen.mixin;

import net.minecraft.entity.ai.brain.task.BreezeJumpTask;
import net.minecraft.entity.mob.BreezeEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static net.minecraft.entity.projectile.AbstractWindChargeEntity.EXPLOSION_BEHAVIOR;

@Mixin(BreezeJumpTask.class)
public abstract class BreezeJumpTaskMixin {
    @Inject(method = "keepRunning(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/entity/mob/BreezeEntity;J)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/mob/BreezeEntity;setNoDrag(Z)V"))
    private void onJumpOrOnLand(ServerWorld serverWorld, BreezeEntity breezeEntity, long l, CallbackInfo ci) {
        if(serverWorld.getDifficulty().getId() > 2) serverWorld.createExplosion(breezeEntity, null, EXPLOSION_BEHAVIOR, breezeEntity.getX(), breezeEntity.getY(), breezeEntity.getZ(), 2.5F, false, World.ExplosionSourceType.TRIGGER, ParticleTypes.GUST_EMITTER_SMALL, ParticleTypes.GUST_EMITTER_LARGE, SoundEvents.ENTITY_WIND_CHARGE_WIND_BURST);
    }
}
