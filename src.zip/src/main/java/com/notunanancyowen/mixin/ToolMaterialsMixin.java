package com.notunanancyowen.mixin;

import net.minecraft.block.Block;
import net.minecraft.item.Items;
import net.minecraft.item.ToolMaterials;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Supplier;

@Mixin(ToolMaterials.class)
@Unique
public abstract class ToolMaterialsMixin {
    @Shadow @Final @Mutable private int itemDurability;
    @Shadow @Final @Mutable private float attackDamage;
    @Inject(method = "<init>", at = @At("TAIL"))
    private void goldToolsGetBuffed(String string, int i, TagKey<Block> inverseTag, int itemDurability, float miningSpeed, float attackDamage, int enchantability, Supplier<Ingredient> repairIngredient, CallbackInfo ci) {
        if (inverseTag.equals(BlockTags.INCORRECT_FOR_GOLD_TOOL) && itemDurability == 32 && miningSpeed == 12.0F && attackDamage == 0.0F && enchantability == 22 && repairIngredient.get().equals(Ingredient.ofItems(Items.GOLD_INGOT))) {
            this.itemDurability += itemDurability * 16;
            this.attackDamage = 2.5F;
        }
    }
}
