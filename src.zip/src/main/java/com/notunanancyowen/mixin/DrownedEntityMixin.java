package com.notunanancyowen.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.notunanancyowen.MobAITweaks;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.RangedAttackMob;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.DrownedEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(DrownedEntity.class)
public abstract class DrownedEntityMixin extends ZombieEntity implements RangedAttackMob {
    DrownedEntityMixin(EntityType<? extends DrownedEntity> type, World world) {
        super(type, world);
    }
    @Override public Box getBoundingBox(EntityPose pose) {
        if(isSwimming()) {
            double x = (getBoundingBox().minY + getBoundingBox().maxY) * 0.5;
            return new Box(-x, 0.6, -x, x, 1.0, x).expand(getScale() * getScaleFactor());
        }
        return super.getBoundingBox(pose);
    }
    @Override protected Box getHitbox() {
        if(isSwimming()) {
            double x = (super.getHitbox().minY + super.getHitbox().maxY) * 0.5;
            return new Box(-x, 0.6, -x, x, 1.0, x).expand(getScale() * getScaleFactor());
        }
        return super.getHitbox();
    }
    @Override public float getPitch() {
        if(getWorld().isClient() && MobAITweaks.FreshAnimationsEnabled() && !MobAITweaks.MobAITweaksExtrasEnabled()) return super.getPitch() + 30f;
        return super.getPitch();
    }
    @Inject(method = "updateSwimming", at = @At("TAIL"))
    private void trySwimming(CallbackInfo ci) {
        if(!isSwimming()) return;
        if(getTarget() != null && distanceTo(getTarget()) < 2 && !getTarget().isSubmergedInWater() && isSubmergedInWater()) addVelocity(getRotationVector().getX() * 0.04, 0.06, getRotationVector().getZ() * 0.04);
        serverPitch = -Math.toDegrees(Math.atan2(getVelocity().getY(), getVelocity().horizontalLength()));
    }
    @ModifyReturnValue(method = "isInSwimmingPose", at = @At("TAIL"))
    private boolean swim(boolean original) {
        if(original) setPose(EntityPose.SWIMMING);
        else setPose(EntityPose.STANDING);
        return original;
    }
    @ModifyReturnValue(method = "createDrownedAttributes", at = @At("TAIL"))
    private static DefaultAttributeContainer.Builder attribution(DefaultAttributeContainer.Builder original) {
        return original.add(EntityAttributes.GENERIC_WATER_MOVEMENT_EFFICIENCY, 0.5d);
    }
}
