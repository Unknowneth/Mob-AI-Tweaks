package com.notunanancyowen.goals;

import com.notunanancyowen.MobAITweaks;
import net.minecraft.entity.AreaEffectCloudEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;


public class HostileMobRandomlySitDownGoal extends Goal {
    private final HostileEntity mob;
    public HostileMobRandomlySitDownGoal(HostileEntity mob) {
        this.mob = mob;
    }
    @Override public boolean canStart() {
        return mob.getRandom().nextInt(150) == 15 && mob.isOnGround() && mob.getAttacker() == null && mob.getTarget() == null && mob.getVehicle() == null && !mob.getNavigation().isFollowingPath() && !mob.getMoveControl().isMoving() && !mob.getLookControl().isLookingAtSpecificPosition();
    }
    @Override public boolean shouldContinue() {
        return false;
    }
    @Override public void start() {
        AreaEffectCloudEntity comfySpot = new AreaEffectCloudEntity(mob.getWorld(), mob.getX(), mob.getY() - 0.4d, mob.getZ()) {
            @Override public void tick() {
                if(getOwner() instanceof HostileEntity owner && (owner.getVehicle() != this || owner.getTarget() != null || owner.getAttacker() != null)) {
                    if(owner.getAttacker() != null && !owner.getAttacker().isInCreativeMode()) owner.setTarget(owner.getAttacker());
                    owner.dismountVehicle();
                    discard();
                    return;
                }
                super.tick();
                if(age > 60 && getOwner() instanceof HostileEntity owner) {
                    owner.setPitch(60F);
                    if(age % 10 == 0) owner.heal(1F);
                }
            }
            @Override public Text getName() {
                return mob.getName();
            }
            @Override public Text getDisplayName() {
                return mob.getDisplayName();
            }
            @Override public Text getCustomName() {
                return mob.getCustomName();
            }
            @Override public ParticleEffect getParticleType() {
                return new BlockStateParticleEffect(ParticleTypes.BLOCK, mob.getSteppingBlockState());
            }
        };
        comfySpot.setOwner(mob);
        comfySpot.addCommandTag(MobAITweaks.MOD_ID + ":" + mob.getName().getString() + "'s seat");
        comfySpot.setDuration(mob.getRandom().nextBetween(200, 500));
        comfySpot.setRadius(0);
        comfySpot.setParticleType(new BlockStateParticleEffect(ParticleTypes.BLOCK, mob.getSteppingBlockState()));
        mob.getWorld().spawnEntity(comfySpot);
        mob.startRiding(comfySpot, true);
    }
}
