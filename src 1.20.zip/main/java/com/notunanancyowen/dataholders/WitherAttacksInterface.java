package com.notunanancyowen.dataholders;

public interface WitherAttacksInterface {
    void setChargeTime(int i);
    int getChargeTime();
    void setSlamTime(int i);
    int getSlamTime();
    boolean isEnraged();
    boolean beBlue();
}
