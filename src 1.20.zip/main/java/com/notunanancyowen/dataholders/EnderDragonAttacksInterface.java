package com.notunanancyowen.dataholders;

public interface EnderDragonAttacksInterface {
    boolean isEnraged();
    void forceMove();
    boolean isDPS();
    void endDPS();
}
