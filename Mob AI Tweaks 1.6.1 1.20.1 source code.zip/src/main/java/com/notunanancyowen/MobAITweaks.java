package com.notunanancyowen;

import com.notunanancyowen.content.enchantments.*;
import net.fabricmc.api.ModInitializer;

import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.GameRules;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

@SuppressWarnings("all")
public class MobAITweaks implements ModInitializer {
	public static final String MOD_ID = "mob-ai-tweaks";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	public static final GameRules.Key<GameRules.BooleanRule> MOBS_ARE_OP = GameRuleRegistry.register("crazyMobs", GameRules.Category.MOBS, GameRuleFactory.createBooleanRule(false));
	@Override public void onInitialize() {
		try {
			if(FabricLoader.getInstance().getConfigDir().resolve(MOD_ID).toFile().mkdir()) LOGGER.info("Added general directory!");
			if(FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + "/blacklists").toFile().mkdir()) LOGGER.info("Added blacklists directory!");
			if(FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + "/sniffer").toFile().mkdir()) LOGGER.info("Added sniffer directory!");
		}
		catch (SecurityException e) {
			LOGGER.info("Error making config directories: %n" + e.getLocalizedMessage());
		}
		try {
			File config = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + "/blacklists/allay_weapons.txt").toFile();
			if(config.createNewFile()) try(FileWriter configWriter = new FileWriter(config)) {
				configWriter.write("#Blacklist for items allays can use in combat, takes their in-game ID (e.g. " + MOD_ID + ":item_to_blacklist)");
				configWriter.close();
			}
		}
		catch (IOException | SecurityException e) {
			LOGGER.info("Error making config: %n" + e.getLocalizedMessage());
		}
		try {
			File config = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + "/blacklists/modded_bows_and_crossbows.txt").toFile();
			if(config.createNewFile()) try(FileWriter configWriter = new FileWriter(config)) {
				configWriter.write("#Dual blacklist for modded bows and crossbows, takes their in-game ID (e.g. " + MOD_ID + ":modded_bow_or_crossbow_item)");
				configWriter.close();
			}
		}
		catch (IOException | SecurityException e) {
			LOGGER.info("Error making config: %n" + e.getLocalizedMessage());
		}
		try {
			File config = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + "/blacklists/allay_weapons.txt").toFile();
			if(config.createNewFile()) try(FileWriter configWriter = new FileWriter(config)) {
				configWriter.write("#Blacklist for items allays can use in combat, takes their in-game ID (e.g. " + MOD_ID + ":item_to_blacklist)");
				configWriter.close();
			}
			try(FileReader configReader = new FileReader(config)) {
				BufferedReader reader = new BufferedReader(configReader);
				StringBuilder bob = new StringBuilder();
				String configText = null;
				while((configText = reader.readLine()) != null) {
					bob.append(configText);
					bob.append(System.getProperty("line.separator"));
				}
				bob.deleteCharAt(bob.length() - 1);
				reader.close();
				bob.toString().lines().forEach(configContent -> {
					if(!configContent.startsWith("#Blacklist")) allayItemBlacklist.add(configContent);
				});
				configReader.close();
			}
		}
		catch (IOException | SecurityException e) {
			LOGGER.info("Error making config: %n" + e.getLocalizedMessage());
		}
		try {
			File config = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + "/blacklists/hostiles_that_can_sit.txt").toFile();
			if(config.createNewFile()) try(FileWriter configWriter = new FileWriter(config)) {
				configWriter.write("#Blacklist for hostile mobs that can sit down randomly, takes their in-game ID (e.g. " + MOD_ID + ":mob_to_blacklist)");
				configWriter.close();
			}
			try(FileReader configReader = new FileReader(config)) {
				BufferedReader reader = new BufferedReader(configReader);
				StringBuilder bob = new StringBuilder();
				String configText = null;
				while((configText = reader.readLine()) != null) {
					bob.append(configText);
					bob.append(System.getProperty("line.separator"));
				}
				bob.deleteCharAt(bob.length() - 1);
				reader.close();
				bob.toString().lines().forEach(configContent -> {
					if(!configContent.startsWith("#Blacklist")) hostilesThatCannotSit.add(configContent);
				});
				configReader.close();
			}
		}
		catch (IOException | SecurityException e) {
			LOGGER.info("Error making config: %n" + e.getLocalizedMessage());
		}
		String snifferConfig = "#Example is as goes, mob-ai-tweaks:item_to_sniff=mob-ai-tweaks:biome_to_find, do note that it supports biome tags but not item tags\n" +
			"minecraft:acacia_sapling=#minecraft:is_savanna\n" +
			"minecraft:bamboo=minecraft:bamboo_jungle\n" +
			"minecraft:birch_sapling=minecraft:birch_forest\n" +
			"minecraft:brown_mushroom=minecraft:swamp\n" +
			"minecraft:cherry_sapling=minecraft:cherry_grove\n" +
			"minecraft:dark_oak_sapling=minecraft:dark_forest\n" +
			"minecraft:mangrove_roots=minecraft:mangrove_swamp\n" +
			"minecraft:oak_sapling=minecraft:forest\n" +
			"minecraft:red_mushroom=minecraft:mushroom_fields\n" +
			"minecraft:red_sand=#minecraft:is_badlands\n" +
			"minecraft:sand=minecraft:desert\n" +
			"minecraft:spruce_sapling=#minecraft:is_taiga\n" +
			"minecraft:sunflower=minecraft:plains";
		try {
			File config = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + "/sniffer/item_to_biome.txt").toFile();
			if(config.createNewFile()) try(FileWriter configWriter = new FileWriter(config)) {
				configWriter.write(snifferConfig);
				configWriter.close();
			}
			try(FileReader configReader = new FileReader(config)) {
				BufferedReader reader = new BufferedReader(configReader);
				StringBuilder bob = new StringBuilder();
				String configText = null;
				while((configText = reader.readLine()) != null) {
					bob.append(configText);
					bob.append(System.getProperty("line.separator"));
				}
				bob.deleteCharAt(bob.length() - 1);
				reader.close();
				bob.toString().lines().forEach(configContent -> {
					if(!configContent.startsWith("#Example")) {
						String[] configValues = configContent.split("=", 2);
						for(int i = 0; i < configValues.length; i++) if(!configValues[i].contains(":")) configValues[i] = configValues[i].contains("#") ? configValues[i].replace("#", "#minecraft:") : "minecraft:" + configValues[i];
						snifferItemToBiome.put(configValues[0], configValues[1]);
					}
				});
				configReader.close();
			}
		}
		catch (IOException | SecurityException e) {
			LOGGER.info("Error making config: %n" + e.getLocalizedMessage());
		}
		String originalConfig = "#All cooldowns are in ticks and all chances are in percentage\n" +
			"allay_rework=true\n" +
			"blaze_extra_fireballs_count=0\n" +
			"blazes_strafe_when_shooting=true\n" +
			"bosses_enrage=true\n" +
			"bosses_announce_spawn_and_death=true\n" +
			"burn_and_freeze_visual_effects=true\n" +
			"chickens_flee_from_mobs=true\n" +
			"chickens_shed_feathers=true\n" +
			"chickens_shed_feather_chance=50\n" +
			"creeper_explosions_rework=true\n" +
			"disable_golem_infighting=true\n" +
			"drowned_rework=true\n" +
			"drowned_swimming_animation=true\n" +
			"enchantments_from_mod=true\n" +
			"ender_dragon_rework=true\n" +
			"elder_guardians_are_bosses=true\n" +
			"elder_guardians_boss_armor=8\n" +
			"elder_guardians_boss_health=150\n" +
			"evokers_cast_fireball=true\n" +
			"evokers_cast_fireball_cooldown=20\n" +
			"ghasts_cry_tears=true\n" +
			"ghasts_cry_tears_cooldown=60\n" +
			"hostile_mobs_can_escape_boats=true\n" +
			"hostile_mobs_can_sit=true\n" +
			"hostile_mobs_sitting_can_be_startled=true\n" +
			"husks_can_burrow=true\n" +
			"illagers_and_zombie_villagers_fight=true\n" +
			"illagers_use_boats=true\n" +
			"line_of_sight_rework=true\n" +
			"melee_mobs_jump_to_reach=true\n" +
			"phantom_rework=true\n" +
			"phantoms_from_spawner_always_attack=true\n" +
			"pillagers_eat_food=true\n" +
			"pillagers_can_melee_attack=true\n" +
			"pillagers_use_modded_crossbows=true\n" +
			"ranged_mobs_reposition=true\n" +
			"ranged_mobs_use_guns=true\n" +
			"ravagers_are_minibosses=true\n" +
			"ravager_special_attacks=true\n" +
			"ravager_special_attack_cooldown=180\n" +
			"skeleton_babies=true\n" +
			"skeleton_horsemen=true\n" +
			"skeleton_sniper_AI=true\n" +
			"skeleton_special_attacks=true\n" +
			"skeleton_special_attack_cooldown=200\n" +
			"skeleton_strafe_speed_buff=true\n" +
			"skeletons_can_convert_to_wither=true\n" +
			"skeletons_use_modded_bows=true\n" +
			"sneak_to_approach_animals=true\n" +
			"sniffer_announces_biome_find=true\n" +
			"sniffer_announces_block_find=true\n" +
			"sniffer_rework=true\n" +
			"snow_golem_rework=true\n" +
			"snow_golem_pumpkin_can_be_returned=true\n" +
			"snow_golem_armor_if_it_has_pumpkin=10\n" +
			"snow_golem_accuracy_when_no_pumpkin=2\n" +
			"stray_special_attacks=true\n" +
			"stray_special_attack_cooldown=120\n" +
			"throwable_fire_charges=true\n" +
			"undead_horses_burn_in_day=true\n" +
			"vex_rework=true\n" +
			"villagers_eat_food=true\n" +
			"villagers_have_special_roles=true\n" +
			"wardens_get_stunned_by_bells=true\n" +
			"wither_death_animation=true\n" +
			"wither_rework=true\n" +
			"wither_boss_armor=12\n" +
			"wither_boss_follow_range=120\n" +
			"wither_boss_health=300\n" +
			"wither_skeleton_special_attacks=true\n" +
			"wither_skeleton_special_attack_cooldown=200\n" +
			"wither_skeletons_with_bows_chance=10\n" +
			"zombie_dads_from_bedrock=true\n" +
			"zombie_leader_rework=true\n" +
			"zombie_pigmen_can_use_crossbows=true\n" +
			"zombie_pigmen_with_crossbows_chance=20\n" +
			"zombie_villager_special_attacks=true";
		long originalConfigSize = originalConfig.lines().count();
		try {
			File config = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + "/general_config.txt").toFile();
			if(config.createNewFile()) try(FileWriter configWriter = new FileWriter(config)) {
				configWriter.write(originalConfig);
				configWriter.close();
			}
			try(FileReader configReader = new FileReader(config)) {
				BufferedReader reader = new BufferedReader(configReader);
				StringBuilder bob = new StringBuilder();
				String configText = null;
				int tries = -1;
				while(++tries <= originalConfigSize && (configText = reader.readLine()) != null) {
					bob.append(configText);
					bob.append(System.getProperty("line.separator"));
				}
				bob.deleteCharAt(bob.length() - 1);
				reader.close();
				bob.toString().lines().forEach(configContent -> {
					if(!configContent.startsWith("#") && configContent.contains("=")) {
						String[] configValues = configContent.split("=", 2);
						if(configValues[1].contains("false")) disabledFeatures.add(configValues[0]);
						else if(configValues[0].contains("enchantments_from_mod") || !bob.toString().contains("enchantments_from_mod")) try {
							Registry.register(Registries.ENCHANTMENT, new Identifier(MOD_ID, "after_burner"), new AfterBurner());
							Registry.register(Registries.ENCHANTMENT, new Identifier(MOD_ID, "auto_loading_holster"), new AutoLoadingHolster());
							Registry.register(Registries.ENCHANTMENT, new Identifier(MOD_ID, "blasting_impression"), new BlastingImpression());
							Registry.register(Registries.ENCHANTMENT, new Identifier(MOD_ID, "despise"), new Despise());
							Registry.register(Registries.ENCHANTMENT, new Identifier(MOD_ID, "featherweight_munitions"), new FeatherweightMunitions());
							Registry.register(Registries.ENCHANTMENT, new Identifier(MOD_ID, "full_auto_retrofit"), new FullAutoRetrofit());
							Registry.register(Registries.ENCHANTMENT, new Identifier(MOD_ID, "grappling_bobber"), new GrapplingBobber());
							Registry.register(Registries.ENCHANTMENT, new Identifier(MOD_ID, "kick_back"), new KickBack());
							Registry.register(Registries.ENCHANTMENT, new Identifier(MOD_ID, "recall"), new Recall());
							Registry.register(Registries.ENCHANTMENT, new Identifier(MOD_ID, "withering_munitions"), new WitheringMunitions());
						}
						catch (Throwable ignore) {
						}
						else if(!configValues[1].contains("true")) {
							boolean putItIn = true;
							for(int i = 0; i < configValues[1].length(); i++) if(!Character.isDigit(configValues[1].charAt(i))) {
								putItIn = false;
								break;
							}
							if(putItIn) configIntegers.put(configValues[0], Integer.valueOf(configValues[1]));
						}
					}
				});
				configReader.close();
				if(bob.toString().lines().count() == originalConfigSize) return;
			}
			config.delete();
			if(config.createNewFile()) try(FileWriter configWriter = new FileWriter(config)) {
				originalConfig.lines().forEach(configContent -> {
					if(configContent.startsWith("#") || !configContent.contains("=")) {
						try {
							configWriter.append(configContent);
							if(originalConfig.lines().toList().indexOf(configContent) < originalConfigSize - 1) configWriter.append(System.getProperty("line.separator"));
						}
						catch (IOException e) {
							return;
						}
						return;
					}
					String[] configValues = configContent.split("=", 2);
					if(configIntegers.containsKey(configValues[0])) {
						try {
							String number = "";
							for(int i = 0; i < configValues[1].length(); i++) if(Character.isDigit(configValues[1].charAt(i))) number += configValues[1].charAt(i);
							configContent = configValues[0] + "=" + getModConfigValue(configValues[0], Integer.valueOf(number));
							configWriter.append(configContent);
							if(originalConfig.lines().toList().indexOf(configContent) < originalConfigSize - 1) configWriter.append(System.getProperty("line.separator"));
						}
						catch (IOException e) {
							return;
						}
						return;
					}
					if(disabledFeatures.contains(configValues[0]) || configValues[1].contains("false")) configContent = configContent.replace("true", "false");
					try {
						configWriter.append(configContent);
						if(originalConfig.lines().toList().indexOf(configContent) < originalConfigSize - 1) configWriter.append(System.getProperty("line.separator"));
					}
					catch (IOException e) {
					}
				});
				configWriter.close();
			}
			LOGGER.info("Config updated!");
		}
		catch (IOException | SecurityException e) {
			LOGGER.info("Error making config: %n" + e.getLocalizedMessage());
		}
		LOGGER.info("Mob AIs have been tweaked!");
	}
	private final static HashMap<String, Integer> configIntegers = new HashMap<>();
	private final static ArrayList<String> disabledFeatures = new ArrayList<>();
	private final static ArrayList<Item> possibleBows = new ArrayList<>();
	private final static ArrayList<Item> possibleCrossbows = new ArrayList<>();
	public static Item getRandomBow(Random random) {
		if(!getModConfigValue("skeletons_use_modded_bows")) return Items.BOW;
		if(possibleBows.isEmpty()) {
			LOGGER.info("List of possible modded bow items are empty, preparing to fill up...");
			Registries.ITEM.stream().filter(item -> item instanceof BowItem).forEach(item -> possibleBows.add(item));
			if(possibleBows.size() > 1) {
				try {
					File config = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + "/blacklists/modded_bows_and_crossbows.txt").toFile();
					if(config.exists()) try(FileReader configReader = new FileReader(config)) {
						BufferedReader reader = new BufferedReader(configReader);
						StringBuilder bob = new StringBuilder();
						String configText = null;
						int tries = -1;
						while(++tries < Integer.MAX_VALUE && (configText = reader.readLine()) != null) {
							bob.append(configText);
							bob.append(System.getProperty("line.separator"));
						}
						bob.deleteCharAt(bob.length() - 1);
						reader.close();
						String b = bob.toString();
						String blacklist = b.substring(b.indexOf(")") + 1);
						if(possibleBows.removeIf(bow -> blacklist.contains(bow.toString()))) LOGGER.info(String.format("Some modded bow items have been blacklisted..."));
						configReader.close();
					}
				}
				catch (IOException | SecurityException e) {
					LOGGER.info("Error reading config: %n" + e.getLocalizedMessage());
				}
				LOGGER.info(String.format("Found %d modded bow items, all have been registered. Expect skeletons to spawn with them!", possibleBows.size()));
			}
			else LOGGER.info("No modded bow items have been found!");
		}
		return possibleBows.size() > 1 ? possibleBows.get(random.nextInt(possibleBows.size() - 1) + 1) : Items.BOW;
	}
	public static Item getRandomCrossbow(Random random) {
		if(!getModConfigValue("pillagers_use_modded_crossbows")) return Items.CROSSBOW;
		if(possibleCrossbows.isEmpty()) {
			LOGGER.info("List of possible modded crossbow items are empty, preparing to fill up...");
			Registries.ITEM.stream().filter(item -> item instanceof CrossbowItem).forEach(item -> possibleCrossbows.add(item));
			if(possibleCrossbows.size() > 1) {
				try {
					File config = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + "/blacklists/modded_bows_and_crossbows.txt").toFile();
					if(config.exists()) try(FileReader configReader = new FileReader(config)) {
						BufferedReader reader = new BufferedReader(configReader);
						StringBuilder bob = new StringBuilder();
						String configText = null;
						int tries = -1;
						while(++tries < Integer.MAX_VALUE && (configText = reader.readLine()) != null) {
							bob.append(configText);
							bob.append(System.getProperty("line.separator"));
						}
						bob.deleteCharAt(bob.length() - 1);
						reader.close();
						String b = bob.toString();
						String blacklist = b.substring(b.indexOf(")") + 1);
						if(possibleCrossbows.removeIf(crossbow -> blacklist.contains(crossbow.toString()))) LOGGER.info(String.format("Some modded bow items have been blacklisted..."));
						configReader.close();
					}
				}
				catch (IOException | SecurityException e) {
					LOGGER.info("Error reading config: %n" + e.getLocalizedMessage());
				}
				LOGGER.info(String.format("Found %d modded crossbow items, all have been registered. Expect pillagers to spawn with them!", possibleCrossbows.size()));
			}
			else LOGGER.info("No modded crossbow items have been found!");
		}
		return possibleCrossbows.size() > 1 ? possibleCrossbows.get(random.nextInt(possibleCrossbows.size() - 1) + 1) : Items.CROSSBOW;
	}
	public static boolean getModConfigValue(String whatToGet) {
		if(disabledFeatures == null || disabledFeatures.isEmpty()) {
			return true;
		}
		try {
			return !disabledFeatures.contains(whatToGet);
		}
		catch(Exception e) {
			return true;
		}
	}
	public static int getModConfigValue(String whatToGet, int fallback) {
		if(configIntegers == null || configIntegers.isEmpty()) {
			return fallback;
		}
		try {
			return configIntegers.getOrDefault(whatToGet, fallback);
		}
		catch(Throwable ignore) {
			return fallback;
		}
	}
	public static final ArrayList<String> hostilesThatCannotSit = new ArrayList<>();
	public static final ArrayList<String> allayItemBlacklist = new ArrayList<>();
	public static final HashMap<String, String> snifferItemToBiome = new HashMap<>();
}