package com.notunanancyowen.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import com.notunanancyowen.MobAITweaks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.*;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.RangedWeaponItem;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(CrossbowItem.class)
public abstract class CrossbowItemMixin extends RangedWeaponItem {
    @Unique private int autoReloadTime = 0;
    public CrossbowItemMixin(Settings settings) {
        super(settings);
    }
    @Inject(method = "shoot", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;damage(ILnet/minecraft/entity/LivingEntity;Ljava/util/function/Consumer;)V"))
    private static void replaceWithSkull(World world, LivingEntity shooter, Hand hand, ItemStack crossbow, ItemStack projectile, float soundPitch, boolean creative, float speed, float divergence, float simulated, CallbackInfo ci, @Local(index = 11) LocalRef<ProjectileEntity> projectileEntity) {
        if(projectileEntity != null && projectileEntity.get() != null) if(crossbow.getEnchantments().stream().anyMatch(e -> e.asString().contains(MobAITweaks.MOD_ID + ":withering_munitions"))) {
            var velocity = projectileEntity.get().getVelocity();
            if(shooter instanceof PathAwareEntity mob && mob.getTarget() != null) velocity = mob.getTarget().getEyePos().subtract(projectileEntity.get().getPos()).normalize().multiply(velocity.length());
            WitherSkullEntity skull = new WitherSkullEntity(world, shooter, velocity.x, velocity.y, velocity.z);
            skull.setFireTicks(projectileEntity.get().getFireTicks());
            skull.setPosition(projectileEntity.get().getPos());
            skull.setCharged(projectile.isOf(Items.TIPPED_ARROW) || projectile.isOf(Items.FIREWORK_ROCKET) || projectile.isOf(Items.SPECTRAL_ARROW));
            projectileEntity.set(skull);
        }
        else if(crossbow.getEnchantments().stream().anyMatch(e -> e.asString().contains(MobAITweaks.MOD_ID + ":featherweight_munitions"))) {
            projectileEntity.get().setNoGravity(true);
            if(shooter instanceof PathAwareEntity mob && mob.getTarget() != null) projectileEntity.get().setVelocity(mob.getTarget().getEyePos().subtract(projectileEntity.get().getPos()).normalize().multiply(projectileEntity.get().getVelocity().length()));
        }
    }
    @Inject(method = "usageTick", at = @At("TAIL"))
    private void fullAuto(World world, LivingEntity user, ItemStack stack, int remainingUseTicks, CallbackInfo ci) {
        if(world.isClient() || remainingUseTicks > 0 || CrossbowItem.isCharged(stack) || stack.getEnchantments().stream().noneMatch(e -> e.asString().contains(MobAITweaks.MOD_ID + ":full_auto_retrofit"))) return;
        user.stopUsingItem();
    }
    @Override public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if(entity instanceof PlayerEntity player && !world.isClient() && !selected && !CrossbowItem.isCharged(stack) && stack.getEnchantments().stream().anyMatch(e -> e.asString().contains(MobAITweaks.MOD_ID + ":auto_loading_holster"))) if(++autoReloadTime > stack.getMaxUseTime()) stack.onStoppedUsing(world, player, autoReloadTime = 0);
        else stack.usageTick(world, player, autoReloadTime);
        super.inventoryTick(stack, world, entity, slot, selected);
    }
}
