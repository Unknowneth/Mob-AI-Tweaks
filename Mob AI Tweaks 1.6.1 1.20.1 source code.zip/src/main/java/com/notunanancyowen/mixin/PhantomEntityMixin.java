package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.TargetPredicate;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.FlyingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.PhantomEntity;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.LlamaSpitEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.stat.Stats;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Comparator;
import java.util.List;

@Mixin(PhantomEntity.class)
public abstract class PhantomEntityMixin extends FlyingEntity implements Monster {
    @Unique private static final TrackedData<Boolean> FROM_SPAWNER = DataTracker.registerData(PhantomEntityMixin.class, TrackedDataHandlerRegistry.BOOLEAN);
    @Shadow public abstract void setPhantomSize(int size);
    @Shadow public abstract int getPhantomSize();
    PhantomEntityMixin(EntityType<? extends PhantomEntity> type, World world) {
        super(type, world);
    }
    @Override public boolean damage(DamageSource source, float amount) {
        if(MobAITweaks.getModConfigValue("phantom_rework")) if(source.isIn(DamageTypeTags.IS_PROJECTILE)) if(amount > 0f) amount *= 3f;
        else amount += 3f;
        return super.damage(source, amount);
    }
    @Inject(method = "initDataTracker", at = @At("HEAD"))
    private void trackData(CallbackInfo ci) {
        getDataTracker().startTracking(FROM_SPAWNER, false);
    }
    @Inject(method = "initialize", at = @At("TAIL"))
    private void onSpawn(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason spawnReason, EntityData entityData, NbtCompound entityNbt, CallbackInfoReturnable<EntityData> cir) {
        if(spawnReason == SpawnReason.SPAWNER) getDataTracker().set(FROM_SPAWNER, MobAITweaks.getModConfigValue("phantoms_from_spawner_always_attack"));
    }
    @Inject(method = "initGoals", at = @At("TAIL"))
    private void reworkTargeting(CallbackInfo ci) {
        if(!MobAITweaks.getModConfigValue("phantom_rework")) return;
        targetSelector.getGoals().clear();
        targetSelector.add(0, new Goal() {
            private int delay = toGoalTicks(20);
            @Override public boolean canStart() {
                if (delay > 0) {
                    delay--;
                    return false;
                }
                else if(getAttacker() != null) {
                    setTarget(getAttacker());
                    return true;
                }
                else if(getPhantomSize() > 3) {
                    delay = toGoalTicks(60);
                    List<PlayerEntity> list = getWorld().getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(16.0, 64.0, 16.0), p -> p.isAlive() && !p.isCreative() && !p.isSpectator() && distanceTo(p) < 64);
                    if (list.isEmpty()) return false;
                    list.sort(Comparator.comparing(Entity::getY).reversed());
                    for (PlayerEntity player : list) if (isTarget(player, TargetPredicate.DEFAULT)) {
                        setTarget(player);
                        return true;
                    }
                    return false;
                }
                else {
                    delay = toGoalTicks(60);
                    List<AnimalEntity> list = getWorld().getEntitiesByClass(AnimalEntity.class, getBoundingBox().expand(16.0, 64.0, 16.0), p -> distanceTo(p) < 64);
                    if (list.isEmpty()) return false;
                    list.sort(Comparator.comparing(Entity::getY).reversed());
                    for (AnimalEntity animal : list) if(animal instanceof CatEntity) return false;
                    else if (isTarget(animal, TargetPredicate.DEFAULT) && !animal.isBaby()) {
                        setTarget(animal);
                        return true;
                    }
                    return false;
                }
            }
            @Override public boolean shouldContinue() {
                return getTarget() != null && isTarget(getTarget(), TargetPredicate.DEFAULT);
            }
            @Override public void start() {
                if(getWorld().getGameRules().getBoolean(MobAITweaks.MOBS_ARE_OP)) {
                    LlamaSpitEntity spit = new LlamaSpitEntity(EntityType.LLAMA_SPIT, getWorld());
                    spit.setPosition(getEyePos().add(getVelocity()));
                    spit.setOwner(PhantomEntityMixin.this);
                    if(getTarget() != null) spit.setVelocity(getTarget().getEyePos().add(getTarget().getVelocity()).subtract(spit.getPos()).normalize().multiply(2d));
                    else spit.setVelocity(getRotationVector().multiply(2d));
                    getWorld().spawnEntity(spit);
                }
                super.start();
            }
        });
    }
    @Override public boolean onKilledOther(ServerWorld world, LivingEntity other) {
        if(MobAITweaks.getModConfigValue("phantom_rework") && other instanceof AnimalEntity) setPhantomSize(getPhantomSize() + 1);
        return super.onKilledOther(world, other);
    }
    @Override protected void onKilledBy(@Nullable LivingEntity adversary) {
        if(MobAITweaks.getModConfigValue("phantom_rework") && getPhantomSize() > 3 && adversary instanceof PlayerEntity player && player instanceof ServerPlayerEntity serverPlayer) serverPlayer.getStatHandler().setStat(player, Stats.CUSTOM.getOrCreateStat(Stats.TIME_SINCE_REST), 0);
        super.onKilledBy(adversary);
    }
}
