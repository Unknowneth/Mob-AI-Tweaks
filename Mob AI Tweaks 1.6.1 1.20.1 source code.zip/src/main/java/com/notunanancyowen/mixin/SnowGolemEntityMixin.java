package com.notunanancyowen.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.goals.SnowGolemAttackGoal;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.ProjectileAttackGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.passive.GolemEntity;
import net.minecraft.entity.passive.SnowGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(SnowGolemEntity.class)
public abstract class SnowGolemEntityMixin extends GolemEntity {
    @Shadow public abstract boolean hasPumpkin();
    @Shadow public abstract void setHasPumpkin(boolean hasPumpkin);
    protected SnowGolemEntityMixin(EntityType<? extends GolemEntity> type, World world) {
        super(type, world);
    }
    @Inject(method = "initGoals", at = @At("TAIL"))
    private void replaceAI(CallbackInfo ci) {
        if(MobAITweaks.getModConfigValue("snow_golem_rework")) if(goalSelector.getGoals().removeIf(goal -> goal.getGoal() instanceof ProjectileAttackGoal)) goalSelector.add(1, new SnowGolemAttackGoal((SnowGolemEntity)(GolemEntity)this));
    }
    @ModifyReturnValue(method = "createSnowGolemAttributes", at = @At("TAIL"))
    private static DefaultAttributeContainer.Builder addDefense(DefaultAttributeContainer.Builder original) {
        if(!MobAITweaks.getModConfigValue("snow_golem_rework")) return original;
        return original.add(EntityAttributes.GENERIC_ARMOR, MobAITweaks.getModConfigValue("snow_golem_armor_if_it_has_pumpkin", 10));
    }
    @ModifyConstant(method = "attack", constant = @Constant(floatValue = 12F))
    private float becomeMoreAccurateWhenNoMask(float constant) {
        return hasPumpkin() || !MobAITweaks.getModConfigValue("snow_golem_rework") ? constant : MobAITweaks.getModConfigValue("snow_golem_accuracy_when_no_pumpkin", 2);
    }
    @Inject(method = "setHasPumpkin", at = @At("TAIL"))
    private void removeDefenseWhenNoPumpkin(boolean hasPumpkin, CallbackInfo ci) {
        if(!MobAITweaks.getModConfigValue("snow_golem_rework")) return;
        var defense = getAttributes().getCustomInstance(EntityAttributes.GENERIC_ARMOR);
        if(defense != null) defense.setBaseValue(hasPumpkin ? MobAITweaks.getModConfigValue("snow_golem_armor_if_it_has_pumpkin", 10) : 0d);
    }
    @Inject(method = "interactMob", at = @At("HEAD"), cancellable = true)
    private void returnPumpkinHead(PlayerEntity player, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
        if(MobAITweaks.getModConfigValue("snow_golem_rework") && MobAITweaks.getModConfigValue("snow_golem_pumpkin_can_be_returned") && player.getStackInHand(hand).isOf(Items.CARVED_PUMPKIN) && !hasPumpkin()) {
            emitGameEvent(GameEvent.SHEAR, player);
            if (!getWorld().isClient && !player.isCreative()) player.getStackInHand(hand).decrement(1);
            setHasPumpkin(true);
            cir.setReturnValue(ActionResult.PASS);
        }
    }
}
