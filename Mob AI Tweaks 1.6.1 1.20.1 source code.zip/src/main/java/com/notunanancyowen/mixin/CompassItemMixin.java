package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.CompassItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(CompassItem.class)
public abstract class CompassItemMixin extends Item {
    public CompassItemMixin(Settings settings) {
        super(settings);
    }
    @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        var currentItem = user.getStackInHand(hand);
        if(currentItem.getEnchantments().stream().noneMatch(e -> e.asString().contains(MobAITweaks.MOD_ID+ ":recall"))) return super.use(world, user, hand);
        if(user instanceof ServerPlayerEntity player) if(player.getServer() != null && player.getSpawnPointPosition() != null) player.teleport(player.getServer().getWorld(player.getSpawnPointDimension()), player.getSpawnPointPosition().getX(), player.getSpawnPointPosition().getY(), player.getSpawnPointPosition().getZ(), player.getSpawnAngle(), 0F);
        return TypedActionResult.success(currentItem, world.isClient());
    }
}
