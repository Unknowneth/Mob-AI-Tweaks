package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FlintAndSteelItem.class)
public abstract class FlintAndSteelItemMixin extends Item {
    public FlintAndSteelItemMixin(Settings settings) {
        super(settings);
    }
    @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack currentItem = user.getStackInHand(hand);
        var afterBurner = Registries.ENCHANTMENT.get(new Identifier(MobAITweaks.MOD_ID, "after_burner"));
        if(afterBurner == null || currentItem.getEnchantments().stream().noneMatch(e -> e.asString().contains(MobAITweaks.MOD_ID+ ":after_burner"))) return super.use(world, user, hand);
        int afterBurnerLvl = EnchantmentHelper.getLevel(afterBurner, currentItem) - 1;
        world.playSound(user, user.getX(), user.getY(), user.getZ(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 0.5f, world.getRandom().nextFloat() * 0.4f + 0.8f);
        if(!world.isClient()) {
            var shootTo = user.getRotationVector();
            ItemStack item = Items.FIRE_CHARGE.getDefaultStack();
            item.addEnchantment(afterBurner, afterBurnerLvl + 1);
            if(afterBurnerLvl > 0) {
                FireballEntity fireball = new FireballEntity(world, user, shootTo.getX(), shootTo.getY(), shootTo.getZ(), afterBurnerLvl);
                fireball.setPosition(user.getEyePos());
                fireball.setItem(item);
                world.spawnEntity(fireball);
            }
            else {
                SmallFireballEntity smallFireball = new SmallFireballEntity(world, user, shootTo.getX(), shootTo.getY(), shootTo.getZ());
                smallFireball.setPosition(user.getEyePos());
                smallFireball.setItem(item);
                world.spawnEntity(smallFireball);
            }
            if(!user.getAbilities().creativeMode && user instanceof ServerPlayerEntity serverPlayer) currentItem.damage(1, world.getRandom(), serverPlayer);
        }
        user.getItemCooldownManager().set(currentItem.getItem(), 10 + afterBurnerLvl * 2);
        user.incrementStat(Stats.USED.getOrCreateStat(this));
        return TypedActionResult.success(currentItem, world.isClient());
    }
    @Inject(method = "useOnBlock", at = @At("HEAD"), cancellable = true)
    private void removeUseOnBlock(ItemUsageContext context, CallbackInfoReturnable<ActionResult> cir) {
        if(context.getStack().getEnchantments().stream().anyMatch(e -> e.asString().contains(MobAITweaks.MOD_ID+ ":after_burner"))) cir.setReturnValue(ActionResult.PASS);
    }
}
