package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.dataholders.SpecialAttacksInterface;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.mob.*;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @Inject(method = "getOverlay", at = @At("HEAD"), cancellable = true)
    private static void overlayOverride(LivingEntity entity, float whiteOverlayProgress, CallbackInfoReturnable<Integer> cir) {
        if(entity instanceof WitherEntity wither) {
            int i = wither.getInvulnerableTimer();
            if(i > 100) cir.setReturnValue(OverlayTexture.packUv(OverlayTexture.getU(MathHelper.clamp(0.1F * (i - 100), 0F, 1F)), OverlayTexture.getV(false)));
        }
        if(entity instanceof WitherSkeletonEntity skeleton && skeleton instanceof SpecialAttacksInterface attacks && attacks.getSpecialCooldown() > 0) cir.setReturnValue(OverlayTexture.packUv(OverlayTexture.getU((float)Math.sin(Math.PI * (float)attacks.getSpecialCooldown() / 15F)), OverlayTexture.getV(skeleton.hurtTime > 0 || skeleton.deathTime > 0)));
        if(entity instanceof GhastEntity ghast && ghast instanceof SpecialAttacksInterface attacks && attacks.getSpecialCooldown() > 10 && attacks.getSpecialCooldown() < 20) cir.setReturnValue(OverlayTexture.packUv(OverlayTexture.getU((float)Math.sin(Math.PI * (float)(attacks.getSpecialCooldown() - 10) / 10F)), OverlayTexture.getV(ghast.hurtTime > 0 || ghast.deathTime > 0)));
        if(cir.getReturnValue() != null) {
            int originalColor = cir.getReturnValue();
            if(entity.isOnFire() && !entity.isFireImmune()) cir.setReturnValue(ColorHelper.Argb.mixColor(ColorHelper.Argb.getArgb(255, 255, 165 ,0), originalColor));
            else if(entity.isFrozen()) cir.setReturnValue(ColorHelper.Argb.mixColor(ColorHelper.Argb.getArgb(255, 173, 216, 230), originalColor));
        }
    }
    @ModifyConstant(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", constant = @Constant(floatValue = 1F, ordinal = 3))
    private float becomeOrangeWhenBurningAndBlueWhenFreezingR(float constant, LivingEntity entity) {
        return !MobAITweaks.getModConfigValue("burn_and_freeze_visual_effects") ? constant : entity.isFrozen() && !(entity.isOnFire() && !entity.isFireImmune()) ? 173F / 255F : constant;
    }
    @ModifyConstant(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", constant = @Constant(floatValue = 1F, ordinal = 4))
    private float becomeOrangeWhenBurningAndBlueWhenFreezingG(float constant, LivingEntity entity) {
        return !MobAITweaks.getModConfigValue("burn_and_freeze_visual_effects") ? constant : entity.isOnFire() && !entity.isFireImmune() ? 165F / 255F : entity.isFrozen() ? 216F / 255F : constant;
    }
    @ModifyConstant(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", constant = @Constant(floatValue = 1F, ordinal = 5))
    private float becomeOrangeWhenBurningAndBlueWhenFreezingB(float constant, LivingEntity entity) {
        return !MobAITweaks.getModConfigValue("burn_and_freeze_visual_effects") ? constant : entity.isOnFire() && !entity.isFireImmune() ? 0F : entity.isFrozen() ? 230F / 255F : constant;
    }
    @Inject(method = "setupTransforms", at = @At("TAIL"))
    private void performCoolFlip(LivingEntity entity, MatrixStack matrices, float animationProgress, float bodyYaw, float tickDelta, CallbackInfo ci) {
        if(entity instanceof PathAwareEntity mob && mob.isFallFlying()) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0F - mob.getPitch(tickDelta)));
        else if(!entity.hasVehicle() && entity instanceof SpecialAttacksInterface special && (entity instanceof PiglinEntity || entity instanceof StrayEntity) && Math.abs(special.getSpecialCooldown()) < 10 && special.getSpecialCooldown() != 0) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-(special.getSpecialCooldown() - Math.signum(special.getSpecialCooldown()) * tickDelta) * 36F), 0.0F, entity.getHeight() / entity.getScaleFactor() / 2.0F, 0.0F);
    }
}
