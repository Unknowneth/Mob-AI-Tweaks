package com.notunanancyowen.goals;

import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.dataholders.WitherAttacksInterface;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.util.math.Vec2f;

import java.util.EnumSet;

public class WitherStrafeShootGoal extends Goal {
    private final WitherEntity mob;
    private int strafingTime = 0;
    public WitherStrafeShootGoal(HostileEntity mob) {
        this.mob = (WitherEntity) mob;
        setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }
    @Override public boolean canStart() {
        return ((WitherAttacksInterface)mob).getSlamTime() <= 0 && mob.getHealth() > mob.getMaxHealth() * 0.5f && mob.getTarget() != null && mob.getInvulnerableTimer() <= 0;
    }
    @Override public boolean shouldContinue() {
        return ((WitherAttacksInterface)mob).getSlamTime() <= 0 && mob.getHealth() > mob.getMaxHealth() * 0.5f && mob.getTarget() != null;
    }
    @Override public boolean canStop() {
        return ((WitherAttacksInterface)mob).getSlamTime() > 0 || mob.getHealth() <= mob.getMaxHealth() * 0.5f || mob.getTarget() == null;
    }
    @Override public void stop() {
        mob.setVelocity(0, -1d, 0d);
    }
    @Override public boolean shouldRunEveryTick() {
        return true;
    }
    @Override public void tick() {
        if(mob.getHealth() > mob.getMaxHealth() * 0.5f && mob.getTarget() instanceof LivingEntity target) {
            mob.getNavigation().stop();
            mob.stopMovement();
            mob.lookAtEntity(target, 60f, 60f);
            mob.getLookControl().lookAt(target, 90f, 90f);
            mob.getMoveControl().strafeTo(1f, 0f);
            Vec2f strafeMovement = new Vec2f((float)target.getEntityPos().getX(), (float)target.getEntityPos().getZ()).add(new Vec2f(-(float)mob.getEntityPos().getX(), -(float)mob.getEntityPos().getZ())).normalize().multiply(0.4f);
            mob.lastYaw = mob.lastBodyYaw = mob.bodyYaw = (float)Math.atan2(strafeMovement.y, strafeMovement.x);
            if(target.distanceTo(mob) < 12) strafeMovement = strafeMovement.multiply(-1f);
            else if(strafingTime != 0 && ((mob.getEntityWorld().getDifficulty().getId() > 1 && mob.getHealth() < mob.getMaxHealth() * 0.6666f) || ((WitherAttacksInterface)mob).isEnraged()) || getServerWorld(mob).getGameRules().getBoolean(MobAITweaks.MOBS_ARE_OP)) {
                if(strafingTime > 0) strafingTime--;
                else strafingTime++;
                double rotationAmount = Math.signum(strafingTime) * Math.PI / 2;
                strafeMovement = new Vec2f(strafeMovement.x * (float)Math.cos(rotationAmount) - strafeMovement.y * (float)Math.sin(rotationAmount), strafeMovement.x * (float)Math.sin(rotationAmount) + strafeMovement.y * (float)Math.cos(rotationAmount));
            }
            else if(mob.getRandom().nextBoolean()) strafingTime = mob.getRandom().nextBetween(-100, 100);
            mob.setVelocity(strafeMovement.x, Math.signum(target.getEntityPos().getY() + 6 - mob.getEntityPos().getY()) * 0.4d, strafeMovement.y);
        }
        else strafingTime = 0;
    }
}
