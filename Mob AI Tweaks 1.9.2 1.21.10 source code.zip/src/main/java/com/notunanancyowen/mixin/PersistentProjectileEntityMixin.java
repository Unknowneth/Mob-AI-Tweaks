package com.notunanancyowen.mixin;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PersistentProjectileEntity.class)
public abstract class PersistentProjectileEntityMixin extends ProjectileEntity {
    @Shadow private @Nullable ItemStack weapon;
    @Shadow public abstract void setCritical(boolean critical);
    @Shadow public abstract boolean isCritical();
    PersistentProjectileEntityMixin(EntityType<? extends PersistentProjectileEntity> type, World world) {
        super(type, world);
    }
    @Inject(method = "setVelocity", at = @At("HEAD"))
    private void shootThisGuy(double x, double y, double z, float power, float uncertainty, CallbackInfo ci) {
        if(isOnFire() && getEntityWorld() instanceof ServerWorld server) for (int i = 0; i < 3; i++) server.spawnParticles(i == 2 ? ParticleTypes.SMOKE : i == 1 ? ParticleTypes.SMALL_FLAME : ParticleTypes.FLAME, getX(), getY(), getZ(), 3, 0.1d, 0.1d, 0.1d, 0.1d);
        if(weapon != null && weapon.getItem() instanceof CrossbowItem && !isCritical() && getOwner() instanceof HostileEntity mob && mob.getTarget() != null) setCritical(true);
    }
    @Inject(method = "tick", at = @At("TAIL"))
    private void spawnFireWhenBurning(CallbackInfo ci) {
        if(isOnFire() && getEntityWorld() instanceof ServerWorld server) server.spawnParticles(age % 2 == 0 ?  isCritical() ? ParticleTypes.FLAME : ParticleTypes.SMALL_FLAME : ParticleTypes.SMOKE, getX(), getY(), getZ(), 1, 0.1d, 0.1d, 0.1d, 0.05d);
    }
}
