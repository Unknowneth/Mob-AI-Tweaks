package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import com.notunanancyowen.dataholders.SpecialAttacksInterface;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.GhastEntityRenderer;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.GhastEntityModel;
import net.minecraft.client.render.entity.state.GhastEntityRenderState;
import net.minecraft.entity.mob.GhastEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(GhastEntityRenderer.class)
public abstract class GhastEntityRendererMixin extends MobEntityRenderer<GhastEntity, GhastEntityRenderState, GhastEntityModel> {
    public GhastEntityRendererMixin(EntityRendererFactory.Context context, GhastEntityModel entityModel, float f) {
        super(context, entityModel, f);
    }
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/mob/GhastEntity;Lnet/minecraft/client/render/entity/state/GhastEntityRenderState;F)V", at = @At("TAIL"))
    private void addInflateEffect(GhastEntity ghastEntity, GhastEntityRenderState ghastEntityRenderState, float f, CallbackInfo ci) {
        if(ghastEntityRenderState instanceof RenderStateExtender r && ghastEntity instanceof SpecialAttacksInterface s) r.setThis(0, s.getSpecialCooldown());
    }
}
