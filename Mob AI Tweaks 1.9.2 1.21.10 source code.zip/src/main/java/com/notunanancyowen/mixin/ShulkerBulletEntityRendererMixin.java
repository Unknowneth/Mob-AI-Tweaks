package com.notunanancyowen.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.dataholders.RenderStateExtender;
import com.notunanancyowen.dataholders.SpecialAttacksInterface;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.ShulkerBulletEntityRenderer;
import net.minecraft.client.render.entity.state.ShulkerBulletEntityRenderState;
import net.minecraft.entity.projectile.ShulkerBulletEntity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ShulkerBulletEntityRenderer.class)
public abstract class ShulkerBulletEntityRendererMixin {
    @Unique private final static Identifier OTHER_TEXTURE = Identifier.of(MobAITweaks.MOD_ID, "textures/seeking_mine.png");
    @Unique private static final RenderLayer OTHER_LAYER = RenderLayer.getEntityTranslucent(OTHER_TEXTURE);
    @Unique private final static Identifier ANOTHER_TEXTURE = Identifier.of(MobAITweaks.MOD_ID, "textures/seeking_mine.png");
    @Unique private static final RenderLayer ANOTHER_LAYER = RenderLayer.getEntityTranslucent(OTHER_TEXTURE);
    @ModifyArg(method = "render(Lnet/minecraft/client/render/entity/state/ShulkerBulletEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/model/ShulkerBulletEntityModel;getLayer(Lnet/minecraft/util/Identifier;)Lnet/minecraft/client/render/RenderLayer;"))
    private Identifier changeTexture(Identifier par1, @Local(argsOnly = true) ShulkerBulletEntityRenderState s) {
        if(s instanceof RenderStateExtender r && r.getThis(0) instanceof Integer v) return v == 2 ? ANOTHER_TEXTURE : v == 1 ? OTHER_TEXTURE : par1;
        return par1;
    }
    @ModifyArg(method = "render(Lnet/minecraft/client/render/entity/state/ShulkerBulletEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;submitModel(Lnet/minecraft/client/model/Model;Ljava/lang/Object;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/RenderLayer;IIILnet/minecraft/client/render/command/ModelCommandRenderer$CrumblingOverlayCommand;)V"))
    private RenderLayer changeOverlay(RenderLayer layer, @Local(argsOnly = true) ShulkerBulletEntityRenderState s) {
        if(s instanceof RenderStateExtender r && r.getThis(0) instanceof Integer v) return v == 2 ? ANOTHER_LAYER : v == 1 ? OTHER_LAYER : layer;
        return layer;
    }
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/projectile/ShulkerBulletEntity;Lnet/minecraft/client/render/entity/state/ShulkerBulletEntityRenderState;F)V", at = @At("TAIL"))
    private void stuffToAdd(ShulkerBulletEntity shulkerBulletEntity, ShulkerBulletEntityRenderState shulkerBulletEntityRenderState, float f, CallbackInfo ci) {
        if(shulkerBulletEntity instanceof SpecialAttacksInterface s && shulkerBulletEntityRenderState instanceof RenderStateExtender r) r.setThis(0, s.getSpecialCooldown());
    }
}
