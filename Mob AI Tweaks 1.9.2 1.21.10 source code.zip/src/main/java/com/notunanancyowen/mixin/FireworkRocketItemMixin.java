package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.FireworkRocketItem;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FireworkRocketItem.class)
public abstract class FireworkRocketItemMixin {
    @Inject(method = "use", at = @At("HEAD"), cancellable = true)
    private void useWhenMounted(World world, PlayerEntity user, Hand hand, CallbackInfoReturnable<ActionResult> cir) {
        if (MobAITweaks.getModConfigValue("fireworks_boost_mounts") && user.getVehicle() instanceof LivingEntity mount) {
            ItemStack itemStack = user.getStackInHand(hand);
            if (world instanceof ServerWorld serverWorld) {
                if (user.detachAllHeldLeashes(null)) world.playSoundFromEntity(null, user, SoundEvents.ITEM_LEAD_BREAK, SoundCategory.NEUTRAL, 1.0F, 1.0F);
                var d = itemStack.getComponents().get(DataComponentTypes.FIREWORKS);
                if(d != null) {
                    if(mount.isFlyingVehicle()) {
                        var g = mount.getAttributes().getCustomInstance(EntityAttributes.FLYING_SPEED);
                        if(g != null) g.addTemporaryModifier(new EntityAttributeModifier(Identifier.of(MobAITweaks.MOD_ID, "fireworks_boost"), 1, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
                    }
                    mount.addStatusEffect(new StatusEffectInstance(mount.isFlyingVehicle() ? StatusEffects.SPEED : StatusEffects.LEVITATION, d.flightDuration() * 20 - 10, 5, false, false));
                }
                ProjectileEntity.spawn(new FireworkRocketEntity(world, itemStack, mount), serverWorld, itemStack);
                itemStack.decrementUnlessCreative(1, user);
                user.incrementStat(Stats.USED.getOrCreateStat((FireworkRocketItem)(Object)this));
            }
            cir.setReturnValue(ActionResult.SUCCESS);
        }
    }
}
