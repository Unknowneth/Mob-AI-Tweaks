package com.notunanancyowen.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import com.notunanancyowen.MobAITweaks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.WitherSkullEntity;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.RangedWeaponItem;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(CrossbowItem.class)
public abstract class CrossbowItemMixin extends RangedWeaponItem {
    @Shadow public abstract boolean onStoppedUsing(ItemStack stack, World world, LivingEntity user, int remainingUseTicks);
    @Unique private int autoReloadTime = 0;
    public CrossbowItemMixin(Settings settings) {
        super(settings);
    }
    @Inject(method = "createArrowEntity", at = @At("RETURN"), cancellable = true)
    private void replaceArrowWithSomethingElse(World world, LivingEntity shooter, ItemStack weaponStack, ItemStack projectileStack, boolean critical, CallbackInfoReturnable<ProjectileEntity> cir) {
        if(cir.getReturnValue() != null) weaponStack.getEnchantments().getEnchantments().forEach(e -> {
            if(e.matchesId(Identifier.of(MobAITweaks.MOD_ID, "withering_munitions"))) {
                WitherSkullEntity skull = new WitherSkullEntity(world, shooter, cir.getReturnValue().getVelocity());
                if(shooter instanceof MobEntity mob && mob.getTarget() != null) skull.setVelocity(mob.getTarget().getEyePos().subtract(cir.getReturnValue().getEntityPos()).normalize().multiply(skull.getVelocity().length()));
                skull.setFireTicks(cir.getReturnValue().getFireTicks());
                skull.setPosition(cir.getReturnValue().getEntityPos());
                skull.setCharged(!projectileStack.isOf(Items.ARROW));
                cir.setReturnValue(skull);
                return;
            }
            if(e.matchesId(Identifier.of(MobAITweaks.MOD_ID, "featherweight_munitions"))) {
                cir.getReturnValue().setNoGravity(true);
                if(shooter instanceof MobEntity mob && mob.getTarget() != null) cir.getReturnValue().setVelocity(mob.getTarget().getEyePos().subtract(cir.getReturnValue().getEntityPos()).normalize().multiply(cir.getReturnValue().getVelocity().length()));
            }
        });
    }
    @ModifyVariable(method = "shoot", at = @At("HEAD"), index = 7, argsOnly = true)
    private LivingEntity forceNoTarget(LivingEntity value, @Local(index = 2, argsOnly = true) ProjectileEntity projectile) {
        if(projectile instanceof WitherSkullEntity || projectile.hasNoGravity()) return null;
        return value;
    }
    @Inject(method = "usageTick", at = @At("TAIL"))
    private void fullAuto(World world, LivingEntity user, ItemStack stack, int remainingUseTicks, CallbackInfo ci) {
        if(world.isClient() || remainingUseTicks > 0 || CrossbowItem.isCharged(stack) || stack.getEnchantments().getEnchantments().stream().noneMatch(e -> e.matchesId(Identifier.of(MobAITweaks.MOD_ID, "full_auto_retrofit")))) return;
        if(onStoppedUsing(stack, world, user, remainingUseTicks)) user.clearActiveItem();
    }
    @Inject(method = "loadProjectiles", at = @At("HEAD"))
    private static void fullAutoFix(LivingEntity shooter, ItemStack crossbow, CallbackInfoReturnable<Boolean> cir) {
        if(crossbow.getEnchantments().getEnchantments().stream().anyMatch(e -> e.matchesId(Identifier.of(MobAITweaks.MOD_ID, "full_auto_retrofit"))) && shooter.isUsingItem()) shooter.clearActiveItem();
    }
    @Override public void inventoryTick(ItemStack stack, ServerWorld world, Entity entity, @Nullable EquipmentSlot equipmentSlot) {
        if(entity instanceof PlayerEntity player && equipmentSlot != EquipmentSlot.MAINHAND && equipmentSlot != EquipmentSlot.OFFHAND && !CrossbowItem.isCharged(stack) && stack.getEnchantments().getEnchantments().stream().anyMatch(e -> e.matchesId(Identifier.of(MobAITweaks.MOD_ID, "auto_loading_holster")))) if(++autoReloadTime >= CrossbowItem.getPullTime(stack, player)) stack.usageTick(world, player, autoReloadTime = 0);
        super.inventoryTick(stack, world, entity, equipmentSlot);
    }
}
