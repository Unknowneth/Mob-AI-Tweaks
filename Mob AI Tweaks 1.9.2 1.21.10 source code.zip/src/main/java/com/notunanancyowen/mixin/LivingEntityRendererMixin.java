package com.notunanancyowen.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.dataholders.RenderStateExtender;
import com.notunanancyowen.dataholders.SpecialAttacksInterface;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.render.entity.state.GhastEntityRenderState;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.entity.state.WitherEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.CrossbowUser;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.WitchEntity;
import net.minecraft.entity.passive.AllayEntity;
import net.minecraft.entity.passive.SnowGolemEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.item.CrossbowItem;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@SuppressWarnings("all")
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @Inject(method = "setupTransforms", at = @At("TAIL"))
    private void performCoolFlip(LivingEntityRenderState state, MatrixStack matrices, float bodyYaw, float baseHeight, CallbackInfo ci) {
        if(state instanceof RenderStateExtender r) {
            if(state instanceof GhastEntityRenderState) {
                float johnInterloper;
                float xzScaler = 1F;
                float yScaler = 1F;
                int shootTime = 0;
                if(r.getThis(0) instanceof Integer i) shootTime += i;
                if(shootTime < -25) {
                    johnInterloper = Math.clamp(shootTime + 40, 0, 15) / 15F;
                    xzScaler *= 1.2F - johnInterloper * 0.2F;
                }
                else if(shootTime > 20) {
                    johnInterloper = Math.clamp(shootTime - 20, 0, 10) * 0.1F;
                    xzScaler *= 1F + johnInterloper * johnInterloper * 0.2F;
                    yScaler *= 1.2F - (float)Math.sqrt(johnInterloper) * 0.2F;
                }
                else if(shootTime > 10) {
                    johnInterloper = Math.clamp(shootTime - 10, 0, 10) * 0.1F;
                    yScaler *= 1F + johnInterloper * johnInterloper * 0.2F;
                }
                matrices.scale(xzScaler, yScaler, xzScaler);
            }
            if((state instanceof BipedEntityRenderState b ? !b.hasVehicle : true) && (state.entityType.equals(EntityType.BOGGED) || state.entityType.equals(EntityType.STRAY) || state.entityType.equals(EntityType.PIGLIN)) && r.getThis(0) instanceof Integer i && Math.abs(i) < 10 && i != 0) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-(i - Math.signum(i) * (r.getThis(3) instanceof Float f ? f : 0F)) * 36F), 0.0F, state.height / state.baseScale / 2.0F, 0.0F);
            if(state.entityType.equals(EntityType.SILVERFISH) && r.getThis(0) instanceof Integer i && Math.abs(i) < 10 && i != 0 && r.getThis(3) instanceof Float tickDelta) if(i >= -12 && i < 0) {
                matrices.translate(0F, -(1F - (i + 12 + tickDelta) / 12F), 0F);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90F * (1F - (i + 12 + tickDelta) / 12F)));
            }
            else if(i > 4 && i <= 8) {
                matrices.translate(0F, i < 8 ? -(i - 4 + tickDelta) / 4F : -1F, 0F);
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(i < 8 ? 90F - 180F * (i - 4 + tickDelta) / 4F : -90F));
            }
            else if(i > 0 && i <= 4) matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(i < 4 ? 90F * (i + tickDelta) / 4F : 90F));
        }
    }
    @Inject(method = "getOverlay", at = @At("HEAD"), cancellable = true)
    private static void overlayOverride(LivingEntityRenderState state, float whiteOverlayProgress, CallbackInfoReturnable<Integer> cir) {
        if(state instanceof RenderStateExtender r) {
            if(r.getThis(0) instanceof Integer i && i > 0) {
                if(state.entityType.equals(EntityType.WITHER_SKELETON)) cir.setReturnValue(OverlayTexture.packUv(OverlayTexture.getU((float)Math.sin(Math.PI * (float)i / 15F)), OverlayTexture.getV(state.hurt || state.deathTime > 0)));
                if(state.entityType.equals(EntityType.GHAST) && i > 10 && i < 20) cir.setReturnValue(OverlayTexture.packUv(OverlayTexture.getU((float)Math.sin(Math.PI * (float)(i - 10) / 10F)), OverlayTexture.getV(state.hurt || state.deathTime > 0)));
            }
            if(r.getThis(1) instanceof Boolean b1 && b1) cir.setReturnValue(OverlayTexture.packUv(OverlayTexture.getU(0.25F), OverlayTexture.getV(state.hurt || state.deathTime > 0)));
        }
        else if(state instanceof WitherEntityRenderState w && w.invulnerableTimer > 100) cir.setReturnValue(OverlayTexture.packUv(OverlayTexture.getU(Math.clamp(0.1F * (w.invulnerableTimer - 100F), 0F, 1F)), OverlayTexture.getV(false)));
    }
    @ModifyConstant(method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V", constant = @Constant(intValue = -1))
    private int becomeOrangeWhenBurningAndBlueWhenFreezing(int constant, @Local(argsOnly = true) LivingEntityRenderState state) {
        if(state instanceof RenderStateExtender r) {
            if(r.getThis(1) instanceof Boolean b1 && b1) return ColorHelper.getArgb(0, 255, 165 ,0);
            if(r.getThis(2) instanceof Boolean b2 && b2) return ColorHelper.getArgb(0, 173, 216, 230);
        }
        return constant;
    }
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V", at = @At("TAIL"))
    private void addExtraRenderingShenanigans(LivingEntity entity, LivingEntityRenderState state, float f, CallbackInfo ci) {
        if(state instanceof RenderStateExtender r) {
            if(entity instanceof SpecialAttacksInterface s) r.setThis(0, s.getSpecialCooldown());
            if(MobAITweaks.getModConfigValue("burn_and_freeze_visual_effects")) {
                r.setThis(1, entity.isOnFire() && !entity.isFireImmune());
                r.setThis(2, entity.isFrozen());
            }
            r.setThis(3, f);
            if(entity instanceof CrossbowUser) r.setThis(4, entity.getMainHandStack().getItem() instanceof CrossbowItem || entity.getMainHandStack().getItem() instanceof CrossbowItem);
            if(entity instanceof AllayEntity a) r.setThis(4, a.isAttacking());
            else if(entity instanceof VillagerEntity v) r.setThis(4, v.isAttacking());
            else if(entity instanceof SnowGolemEntity sg) r.setThis(4, sg.isLeftHanded());
            else if(entity instanceof WitchEntity w) r.setThis(4, w.isDrinking());
        }
    }
}
