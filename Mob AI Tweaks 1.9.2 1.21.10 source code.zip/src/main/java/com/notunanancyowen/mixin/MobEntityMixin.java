package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.dataholders.SpecialAttacksInterface;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.loot.context.LootWorldContext;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.storage.ReadView;
import net.minecraft.storage.WriteView;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

@Mixin(MobEntity.class)
public abstract class MobEntityMixin extends LivingEntity {
    @Shadow public abstract boolean isAttacking();
    @Shadow public abstract void setAttacking(boolean attacking);
    protected MobEntityMixin(EntityType<? extends LivingEntity> entityType, World world) {
        super(entityType, world);
    }
    @Inject(method = "writeCustomData", at = @At("TAIL"))
    private void addExtraCodeToNbt(WriteView nbt, CallbackInfo ci) {
        if(age == 0) return;
        /*NbtCompound usedItem = new NbtCompound();
        if(isUsingItem()) {
            usedItem.putInt("time", getItemUseTime());
            usedItem.putByte("slot", (dataTracker.get(LIVING_FLAGS) & 2) > 0 ? (byte)1 : (byte)0);
        }
        nbt.put("UsedItem", usedItem);*/
        nbt.putBoolean("IsAggressive", isAttacking());
    }
    @Inject(method = "readCustomData", at = @At("TAIL"))
    private void getExtraCodeToNbt(ReadView nbt, CallbackInfo ci) {
        if(age == 0) return;
        /*if(nbt.contains("UsedItem") && nbt.getCompound("UsedItem").isPresent()) {
            NbtCompound usedItem = nbt.getCompound("UsedItem").get();
            boolean hasSlotParameter = usedItem.contains("slot") && usedItem.getByte("slot").isPresent();
            boolean hasTimeParameter = usedItem.contains("time") && usedItem.getInt("time").isPresent();
            boolean useOffHand = hasSlotParameter && usedItem.getByte("slot").get() == (byte)1;
            var itemToUse = activeItemStack != null ? activeItemStack : useOffHand ? getOffHandStack() : getMainHandStack();
            if(hasTimeParameter) itemUseTimeLeft = itemToUse != null && !itemToUse.isEmpty() ? itemToUse.getMaxUseTime(this) - usedItem.getInt("time").get() : 0;
            if(!hasSlotParameter || usedItem.getByte("slot").get() == (byte)-1) clearActiveItem();
            else setCurrentHand(useOffHand ? Hand.OFF_HAND : Hand.MAIN_HAND);
        }*/
        setAttacking(nbt.getBoolean("IsAggressive", false));
    }
    @Inject(method = "isAttacking", at = @At("TAIL"), cancellable = true)
    private void overrideIsAttackingForSpecialMobs(CallbackInfoReturnable<Boolean> cir) {
        if(this instanceof SpecialAttacksInterface s) if(s.attackType().equals("GRENADE") && s.getSpecialCooldown() > 0) cir.setReturnValue(true);
        else if(s.attackType().equals("FLIP") && Math.abs(s.getSpecialCooldown()) < 10 && s.getSpecialCooldown() != 0) cir.setReturnValue(false);
    }
    @Inject(method = "dropLoot", at = @At("TAIL"))
    private void dropSpecialLoot(ServerWorld world, DamageSource damageSource, boolean causedByPlayer, CallbackInfo ci) {
        if(!MobAITweaks.getModConfigValue("enchantments_from_mod") || getEntityWorld().getServer() == null || getEntityWorld().getServer().getReloadableRegistries() == null) return;
        Optional<RegistryKey<LootTable>> optional = this.getLootTableKey();
        if (optional.isPresent()) {
            LootTable lootTable = world.getServer().getReloadableRegistries().getLootTable(RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of(MobAITweaks.MOD_ID, getType().toString().replace(".", "/"))));
            LootWorldContext.Builder builder = new LootWorldContext.Builder(world)
                    .add(LootContextParameters.THIS_ENTITY, this)
                    .add(LootContextParameters.ORIGIN, this.getEntityPos())
                    .add(LootContextParameters.DAMAGE_SOURCE, damageSource)
                    .addOptional(LootContextParameters.ATTACKING_ENTITY, damageSource.getAttacker())
                    .addOptional(LootContextParameters.DIRECT_ATTACKING_ENTITY, damageSource.getSource());
            PlayerEntity playerEntity = this.getAttackingPlayer();
            if (causedByPlayer && playerEntity != null) {
                builder = builder.add(LootContextParameters.LAST_DAMAGE_PLAYER, playerEntity).luck(playerEntity.getLuck());
            }

            LootWorldContext lootWorldContext = builder.build(LootContextTypes.ENTITY);
            lootTable.generateLoot(lootWorldContext, this.getLootTableSeed(), stack -> this.dropStack(world, stack));
        }
    }
}
