package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.render.entity.PhantomEntityRenderer;
import net.minecraft.client.render.entity.state.PhantomEntityRenderState;
import net.minecraft.entity.mob.PhantomEntity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PhantomEntityRenderer.class)
public abstract class PhantomEntityRendererMixin {
    @Unique private static final Identifier[] UPSCALED_TEXTURE = new Identifier[] {
            Identifier.of(MobAITweaks.MOD_ID, "textures/phantomare/1.png"),
            Identifier.of(MobAITweaks.MOD_ID, "textures/phantomare/2.png"),
            Identifier.of(MobAITweaks.MOD_ID, "textures/phantomare/3.png")
    };
    @Inject(method = "getTexture(Lnet/minecraft/client/render/entity/state/PhantomEntityRenderState;)Lnet/minecraft/util/Identifier;", at = @At("HEAD"), require = 0, cancellable = true)
    private void becomeMoreDetailed(PhantomEntityRenderState phantomEntityRenderState, CallbackInfoReturnable<Identifier> cir) {
        if(phantomEntityRenderState instanceof RenderStateExtender r && r.getThis(4) instanceof Boolean b && b) cir.setReturnValue(UPSCALED_TEXTURE[(int)phantomEntityRenderState.age % 3]);
    }
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/mob/PhantomEntity;Lnet/minecraft/client/render/entity/state/PhantomEntityRenderState;F)V", at = @At("TAIL"), require = 0)
    private void updateVisuals(PhantomEntity phantomEntity, PhantomEntityRenderState phantomEntityRenderState, float f, CallbackInfo ci) {
        if(phantomEntityRenderState instanceof RenderStateExtender r) r.setThis(4, phantomEntity.handSwingProgress == 1F);
    }
}
