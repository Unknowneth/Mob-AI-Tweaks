package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.FireworkRocketEntityRenderer;
import net.minecraft.client.render.entity.state.FireworkRocketEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.Vector2f;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(FireworkRocketEntityRenderer.class)
public abstract class FireworkRocketEntityRendererMixin extends EntityRenderer<FireworkRocketEntity, FireworkRocketEntityRenderState> {
    FireworkRocketEntityRendererMixin(EntityRendererFactory.Context ctx) {
        super(ctx);
    }
    @Inject(method = "render(Lnet/minecraft/client/render/entity/state/FireworkRocketEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V", at = @At("HEAD"), cancellable = true)
    private void reworkVisual(FireworkRocketEntityRenderState state, MatrixStack matrixStack, OrderedRenderCommandQueue orderedRenderCommandQueue, CameraRenderState cameraRenderState, CallbackInfo ci) {
        if(state.shotAtAngle && state instanceof RenderStateExtender r && r.getThis(0) instanceof Vector2f v2) {
            matrixStack.push();
            matrixStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(v2.getY() - 90.0F));
            matrixStack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(v2.getX() - 90.0F));
            matrixStack.multiply(RotationAxis.NEGATIVE_Y.rotationDegrees(90F));
            state.stack.render(matrixStack, orderedRenderCommandQueue, state.light, OverlayTexture.DEFAULT_UV, state.outlineColor);
            matrixStack.pop();
            super.render(state, matrixStack, orderedRenderCommandQueue,  cameraRenderState);
            ci.cancel();
        }
    }
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/projectile/FireworkRocketEntity;Lnet/minecraft/client/render/entity/state/FireworkRocketEntityRenderState;F)V", at = @At("TAIL"))
    private void rotateMyself(FireworkRocketEntity fireworkRocketEntity, FireworkRocketEntityRenderState state, float f, CallbackInfo ci) {
        if(fireworkRocketEntity.wasShotAtAngle() && state instanceof RenderStateExtender r) r.setThis(0, new Vector2f(fireworkRocketEntity.getLerpedPitch(f), fireworkRocketEntity.getLerpedYaw(f)));
    }
}
