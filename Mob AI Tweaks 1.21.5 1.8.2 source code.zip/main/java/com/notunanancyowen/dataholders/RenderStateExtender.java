package com.notunanancyowen.dataholders;

public interface RenderStateExtender {
    default Object getThis(int i) {
        return i;
    }
    default void setThis(int i, Object toSet) {
    }
}
