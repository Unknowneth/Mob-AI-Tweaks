package com.notunanancyowen.dataholders;

public interface SpecialAttacksInterface {
    default void setSpecialCooldown(int i) {
    }
    default int getSpecialCooldown() {
        return 0;
    }
    default void forceSpecialAttack() {
    }
    default String attackType() { return "NONE"; }
}
