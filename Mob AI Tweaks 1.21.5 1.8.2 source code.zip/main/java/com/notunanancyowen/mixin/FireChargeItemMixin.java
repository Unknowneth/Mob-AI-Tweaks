package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.item.FireChargeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FireChargeItem.class)
public abstract class FireChargeItemMixin extends Item {
    public FireChargeItemMixin(Settings settings) {
        super(settings);
    }
    @Override public ActionResult use(World world, PlayerEntity user, Hand hand) {
        ItemStack currentItem = user.getStackInHand(hand);
        if(!MobAITweaks.getModConfigValue("throwable_fire_charges")) return super.use(world, user, hand);
        world.playSound(user, user.getX(), user.getY(), user.getZ(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 0.5f, world.getRandom().nextFloat() * 0.4f + 0.8f);
        if(!world.isClient()) {
            SmallFireballEntity smallFireball = new SmallFireballEntity(world, user.getX(), user.getEyeY(), user.getZ(), user.getRotationVector());
            smallFireball.setOwner(user);
            smallFireball.setItem(currentItem);
            world.spawnEntity(smallFireball);
        }
        user.getItemCooldownManager().set(currentItem, 10);
        user.incrementStat(Stats.USED.getOrCreateStat(this));
        if(!user.getAbilities().creativeMode) currentItem.decrement(1);
        return ActionResult.CONSUME;
    }
    @Inject(method = "useOnBlock", at = @At("HEAD"), cancellable = true)
    private void useOnBlockWhileCrouching(ItemUsageContext context, CallbackInfoReturnable<ActionResult> cir) {
        if(MobAITweaks.getModConfigValue("throwable_fire_charges") && context.getPlayer() != null && !context.getPlayer().isSneaking()) cir.setReturnValue(ActionResult.PASS);
    }
}
