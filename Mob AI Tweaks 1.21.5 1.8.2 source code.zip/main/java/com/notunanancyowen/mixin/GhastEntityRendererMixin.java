package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import com.notunanancyowen.dataholders.SpecialAttacksInterface;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.GhastEntityRenderer;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.GhastEntityModel;
import net.minecraft.client.render.entity.state.GhastEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.mob.GhastEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(GhastEntityRenderer.class)
public abstract class GhastEntityRendererMixin extends MobEntityRenderer<GhastEntity, GhastEntityRenderState, GhastEntityModel> {
    public GhastEntityRendererMixin(EntityRendererFactory.Context context, GhastEntityModel entityModel, float f) {
        super(context, entityModel, f);
    }
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/mob/GhastEntity;Lnet/minecraft/client/render/entity/state/GhastEntityRenderState;F)V", at = @At("TAIL"))
    private void addInflateEffect(GhastEntity ghastEntity, GhastEntityRenderState ghastEntityRenderState, float f, CallbackInfo ci) {
        if(ghastEntityRenderState instanceof RenderStateExtender r && ghastEntity instanceof SpecialAttacksInterface s) r.setThis(0, s.getSpecialCooldown());
    }
    @Override protected void scale(GhastEntityRenderState state, MatrixStack matrices) {
        float johnInterloper;
        float xzScaler = 1F;
        float yScaler = 1F;
        int shootTime = 0;
        if(state instanceof RenderStateExtender r && r.getThis(0) instanceof Integer i) shootTime += i;
        if(shootTime < -25) {
            johnInterloper = Math.clamp(shootTime + 40, 0, 15) / 15F;
            xzScaler *= 1.2F - johnInterloper * 0.2F;
        }
        else if(shootTime > 20) {
            johnInterloper = Math.clamp(shootTime - 20, 0, 10) * 0.1F;
            xzScaler *= 1F + johnInterloper * johnInterloper * 0.2F;
            yScaler *= 1.2F - (float)Math.sqrt(johnInterloper) * 0.2F;
        }
        else if(shootTime > 10) {
            johnInterloper = Math.clamp(shootTime - 10, 0, 10) * 0.1F;
            yScaler *= 1F + johnInterloper * johnInterloper * 0.2F;
        }
        matrices.scale(xzScaler, yScaler, xzScaler);
        super.scale(state, matrices);
    }
}
