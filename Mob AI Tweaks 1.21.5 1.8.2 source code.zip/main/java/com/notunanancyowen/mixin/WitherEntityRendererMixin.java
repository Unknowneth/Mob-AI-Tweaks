package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import com.notunanancyowen.dataholders.WitherAttacksInterface;
import net.minecraft.client.render.entity.WitherEntityRenderer;
import net.minecraft.client.render.entity.state.WitherEntityRenderState;
import net.minecraft.entity.boss.WitherEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WitherEntityRenderer.class)
public abstract class WitherEntityRendererMixin {
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/boss/WitherEntity;Lnet/minecraft/client/render/entity/state/WitherEntityRenderState;F)V", at = @At("TAIL"))
    private void witherAttacks(WitherEntity witherEntity, WitherEntityRenderState witherEntityRenderState, float f, CallbackInfo ci) {
        if(witherEntity instanceof WitherAttacksInterface w && witherEntityRenderState instanceof RenderStateExtender r) {
            r.setThis(0, w.getChargeTime());
            r.setThis(1, w.getSlamTime());
            if(w.beBlue() || witherEntity.getHealth() < witherEntity.getMaxHealth() * 0.16666f) witherEntityRenderState.invulnerableTimer = 1;
        }
    }
}
