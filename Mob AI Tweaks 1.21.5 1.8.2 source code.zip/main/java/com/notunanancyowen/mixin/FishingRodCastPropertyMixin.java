package com.notunanancyowen.mixin;

import net.minecraft.client.render.item.property.bool.FishingRodCastProperty;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FishingRodCastProperty.class)
public abstract class FishingRodCastPropertyMixin {
    @Inject(method = "test", at = @At("TAIL"), cancellable = true)
    private void forceCastingAnimation(ItemStack stack, ClientWorld world, LivingEntity entity, int seed, ItemDisplayContext displayContext, CallbackInfoReturnable<Boolean> cir) {
        if(!cir.getReturnValue() && entity instanceof PathAwareEntity m && m.isUsingItem()) cir.setReturnValue(true);
    }
}
