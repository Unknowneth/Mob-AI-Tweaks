package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.render.entity.feature.VillagerHeldItemFeatureRenderer;
import net.minecraft.client.render.entity.state.ItemHolderEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(VillagerHeldItemFeatureRenderer.class)
public abstract class VillagerHeldItemFeatureRendererMixin {
    @Inject(method = "applyTransforms", at = @At("TAIL"))
    private void changeRenderStyleForFishingRodsOnly(ItemHolderEntityRenderState state, MatrixStack matrices, CallbackInfo ci) {
        if(state instanceof RenderStateExtender r && r.getThis(4) instanceof Boolean b && b) {
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(45.0F));
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0F));
        }
    }
}
