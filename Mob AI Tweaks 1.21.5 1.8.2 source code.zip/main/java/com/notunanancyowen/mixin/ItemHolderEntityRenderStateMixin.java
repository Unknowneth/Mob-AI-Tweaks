package com.notunanancyowen.mixin;

import net.minecraft.client.render.entity.state.ItemHolderEntityRenderState;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.item.ItemDisplayContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(ItemHolderEntityRenderState.class)
public abstract class ItemHolderEntityRenderStateMixin {
    @ModifyArgs(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/item/ItemModelManager;updateForLivingEntity(Lnet/minecraft/client/render/item/ItemRenderState;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/entity/LivingEntity;)V"))
    private static void changeRenderStyleForFishingRodsOnly(Args args) {
        if(args.get(3) instanceof VillagerEntity villager && villager.isAttacking()) args.set(2, ItemDisplayContext.THIRD_PERSON_RIGHT_HAND);
    }
}
