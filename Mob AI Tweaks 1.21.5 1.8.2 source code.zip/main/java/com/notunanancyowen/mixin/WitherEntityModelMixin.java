package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.WitherEntityModel;
import net.minecraft.client.render.entity.state.WitherEntityRenderState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WitherEntityModel.class)
public abstract class WitherEntityModelMixin {
    @Shadow @Final private ModelPart ribcage;
    @Shadow @Final private ModelPart tail;
    @Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/WitherEntityRenderState;)V", at = @At("TAIL"))
    private void newAttackAnimations(WitherEntityRenderState witherEntityRenderState, CallbackInfo ci) {
        float charge = witherEntityRenderState instanceof RenderStateExtender r ? r.getThis(0) instanceof Integer i ? i : 0 : 0;
        if (charge > 0) {
            if(charge > 50) charge = 1F - Math.clamp((charge - 50) / 20F, 0F, 1F);
            float lerpAmount = Math.clamp(charge / 20F, 0F, 1F) * (float)(Math.PI * 0.25f);
            ribcage.pitch += lerpAmount;
            tail.setOrigin(-2.0F, 6.9F + (float)Math.cos(ribcage.pitch) * 10.0F, -0.5F + (float)Math.sin(ribcage.pitch) * 10.0F);
            tail.pitch += lerpAmount;
        }
        charge = witherEntityRenderState instanceof RenderStateExtender r ? r.getThis(1) instanceof Integer i ? i : 0 : 0;
        if (charge > 0 && charge < 50) {
            float lerpAmount = Math.clamp(charge / 20F, 0F, 1F) * (float)(Math.PI * 0.4f);
            ribcage.pitch += lerpAmount;
            tail.setOrigin(-2.0F, 6.9F + (float)Math.cos(ribcage.pitch) * 10.0F, -0.5F + (float)Math.sin(ribcage.pitch) * 10.0F);
            tail.pitch += lerpAmount;
        }
    }
}
