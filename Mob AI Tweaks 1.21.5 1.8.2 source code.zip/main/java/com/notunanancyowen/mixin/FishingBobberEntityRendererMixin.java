package com.notunanancyowen.mixin;

import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.FishingBobberEntityRenderer;
import net.minecraft.client.render.entity.state.FishingBobberEntityState;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FishingBobberEntityRenderer.class)
public abstract class FishingBobberEntityRendererMixin extends EntityRenderer<FishingBobberEntity, FishingBobberEntityState> {
    protected FishingBobberEntityRendererMixin(EntityRendererFactory.Context context) {
        super(context);
    }
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/projectile/FishingBobberEntity;Lnet/minecraft/client/render/entity/state/FishingBobberEntityState;F)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/EntityRenderer;updateRenderState(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/entity/state/EntityRenderState;F)V", shift = At.Shift.AFTER), cancellable = true)
    private void renderStateFix(FishingBobberEntity fishingBobberEntity, FishingBobberEntityState fishingBobberEntityState, float f, CallbackInfo ci) {
        if(fishingBobberEntity.getOwner() instanceof PathAwareEntity mob) {
            Vec3d vec3d = getHandPosNotPlayer(mob, f);
            Vec3d vec3d2 = fishingBobberEntity.getLerpedPos(f).add(0.0, 0.25, 0.0);
            fishingBobberEntityState.pos = vec3d.subtract(vec3d2);
            ci.cancel();
        }
    }
    @Inject(method = "shouldRender(Lnet/minecraft/entity/projectile/FishingBobberEntity;Lnet/minecraft/client/render/Frustum;DDD)Z", at = @At("HEAD"), cancellable = true)
    private void forceRender(FishingBobberEntity fishingBobberEntity, Frustum frustum, double d, double e, double f, CallbackInfoReturnable<Boolean> cir) {
        if(fishingBobberEntity.getOwner() instanceof PathAwareEntity) cir.setReturnValue(super.shouldRender(fishingBobberEntity, frustum, d, e, f));
    }
    @Unique private Vec3d getHandPosNotPlayer(PathAwareEntity mob, float tickDelta) {
        int i = mob instanceof VillagerEntity v && v.isAttacking() ? 0 : mob.getMainArm() == Arm.RIGHT ? 1 : -1;
        ItemStack itemStack = mob.getMainHandStack();
        if (!itemStack.isOf(Items.FISHING_ROD)) i = -i;
        float g = MathHelper.lerp(tickDelta, mob.lastBodyYaw, mob.bodyYaw) * (float) (Math.PI / 180.0);
        double c = 0;
        if(mob instanceof ZombieEntity z) c = (float)Math.PI / (z.isAttacking() ? 1.5F : 2.25F) - 0.66F + MathHelper.sin(z.getHandSwingProgress(tickDelta) * (float) Math.PI) * 1.2F - MathHelper.sin((1.0F - (1.0F - z.getHandSwingProgress(tickDelta)) * (1.0F - z.getHandSwingProgress(tickDelta))) * (float) Math.PI) * 0.4F;
        double d = MathHelper.sin(g);
        double e = MathHelper.cos(g);
        float h = mob.getScale();
        double j = (double)i * 0.35 * (double)h;
        double k = i == 0 ? 0.65 * (double)h : c != 0 ? (float)-Math.cos(c) : 0.0;
        float l = mob.isInSneakingPose() ? -0.1875F : 0.0F;
        if(i == 0) l += 0.5F;
        else if(c != 0) l += (float)Math.sin(c);
        return mob.getCameraPosVec(tickDelta).add(-e * j - d * k, (double)l - 0.45 * (double)h, -d * j + e * k);
    }
}
