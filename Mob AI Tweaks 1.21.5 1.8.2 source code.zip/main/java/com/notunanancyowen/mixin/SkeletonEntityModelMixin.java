package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.ArmPosing;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.SkeletonEntityModel;
import net.minecraft.client.render.entity.state.SkeletonEntityRenderState;
import net.minecraft.entity.EntityType;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(value = SkeletonEntityModel.class)
public abstract class SkeletonEntityModelMixin<S extends SkeletonEntityRenderState> extends BipedEntityModel<S> {
    private SkeletonEntityModelMixin(ModelPart modelPart) {
        super(modelPart);
    }
    @Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/SkeletonEntityRenderState;)V", at = @At("TAIL"))
    private void animateThis(SkeletonEntityRenderState state, CallbackInfo ci) {
        if(state.holdingBow) {
            float rotateArm = (float)(Math.PI * state.itemUseTime / 180.0);
            if(state.mainArm == Arm.RIGHT) {
                rightArm.yaw = rightArm.yaw * (1f - rotateArm / 20F) + head.yaw * (rotateArm / 20F);
                leftArm.yaw += rotateArm * 1.5F;
                body.yaw -= rotateArm;
            }
            else if(state.mainArm == Arm.LEFT) {
                leftArm.yaw = leftArm.yaw * (1f - rotateArm / 20F) + head.yaw * (rotateArm / 20F);
                rightArm.yaw -= rotateArm * 1.5F;
                body.yaw += rotateArm;
            }
        }
        else if(state.entityType.equals(EntityType.WITHER_SKELETON) && state instanceof RenderStateExtender r) {
            float specialAttackProgress = (r.getThis(0) instanceof Integer i ? i + (r.getThis(3) instanceof Float f ? f : 0F) : 0) * 0.1F;
            if(specialAttackProgress > 2f) {
                specialAttackProgress = 1f - (specialAttackProgress - 2f);
                rightArm.pitch += specialAttackProgress * 2f;
                leftArm.pitch += specialAttackProgress * 2f;
                body.pitch += specialAttackProgress * 0.3F;
            }
            else if(specialAttackProgress > 1F) {
                rightArm.pitch--;
                leftArm.pitch--;
                body.pitch -= 0.3F;
                specialAttackProgress--;
                specialAttackProgress *= specialAttackProgress * specialAttackProgress;
                rightArm.pitch += specialAttackProgress * 3F;
                leftArm.pitch += specialAttackProgress * 3F;
                body.pitch += specialAttackProgress * 0.6F;
            }
            else {
                specialAttackProgress *= specialAttackProgress;
                rightArm.pitch -= specialAttackProgress;
                leftArm.pitch -= specialAttackProgress;
                body.pitch -= specialAttackProgress * 0.3F;
            }
        }
        else {
            float k = MathHelper.sin(state.handSwingProgress * (float)Math.PI);
            float l = MathHelper.sin((1.0F - (1.0F - state.handSwingProgress) * (1.0F - state.handSwingProgress)) * (float) Math.PI);
            rightArm.roll = 0.0F;
            leftArm.roll = 0.0F;
            rightArm.yaw = -(0.1F - k * 0.6F);
            leftArm.yaw = 0.1F - k * 0.6F;
            rightArm.pitch = (float) (-Math.PI / 2) + k * 1.2F - l * 0.4F;
            leftArm.pitch = (float) (-Math.PI / 2) + k * 1.2F - l * 0.4F;
            ArmPosing.swingArms(rightArm, leftArm, state.age);
        }
        if(state.baby) {
            root.moveOrigin(new Vector3f(0F, 12F, 0F));
            root.scale(new Vector3f(-0.5F));
            head.scale(new Vector3f(0.4F));
        }
    }
}
