package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.AllayEntityModel;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.AllayEntityRenderState;
import net.minecraft.entity.passive.AllayEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AllayEntityModel.class)
public abstract class AllayEntityModelMixin extends EntityModel<AllayEntityRenderState> {
    @Shadow @Final private ModelPart rightArm;
    @Shadow @Final private ModelPart leftArm;
    @Shadow @Final private ModelPart head;
    @Shadow @Final private ModelPart body;
    protected AllayEntityModelMixin(ModelPart root) {
        super(root);
    }
    @Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/AllayEntityRenderState;)V", at = @At("TAIL"))
    private void allayAnimationTweaks(AllayEntityRenderState state, CallbackInfo ci) {
        if(state instanceof RenderStateExtender r && r.getThis(4) instanceof Boolean b && !b) return;
        float aimRot = head.pitch - body.pitch - root.pitch - (float)(Math.PI / 2);
        rightArm.roll = 0;
        rightArm.yaw *= -1.1f;
        rightArm.pitch = aimRot;
        leftArm.roll = 0;
        leftArm.yaw *= -1.1f;
        leftArm.pitch = aimRot;
    }
}
