package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.render.entity.state.FireworkRocketEntityRenderState;
import net.minecraft.client.util.math.Vector2f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@SuppressWarnings("all")
@Mixin(FireworkRocketEntityRenderState.class)
public abstract class FireworkRocketEntityRenderStateMixin implements RenderStateExtender {
    @Unique Vector2f rotation;
    @Override public Object getThis(int i) {
        return rotation;
    }
    @Override public void setThis(int i, Object toSet) {
        if(toSet instanceof Vector2f v2) rotation = v2;
    }

}
