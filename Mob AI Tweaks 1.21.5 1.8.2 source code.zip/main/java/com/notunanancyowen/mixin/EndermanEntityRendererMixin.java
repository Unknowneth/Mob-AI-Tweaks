package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.render.entity.EndermanEntityRenderer;
import net.minecraft.client.render.entity.state.EndermanEntityRenderState;
import net.minecraft.entity.mob.EndermanEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EndermanEntityRenderer.class)
public abstract class EndermanEntityRendererMixin {
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/mob/EndermanEntity;Lnet/minecraft/client/render/entity/state/EndermanEntityRenderState;F)V", at = @At("TAIL"))
    private void updateVisuals(EndermanEntity endermanEntity, EndermanEntityRenderState endermanEntityRenderState, float f, CallbackInfo ci) {
        if(endermanEntityRenderState instanceof RenderStateExtender r) r.setThis(4, endermanEntity.isAttacking());
    }
}
