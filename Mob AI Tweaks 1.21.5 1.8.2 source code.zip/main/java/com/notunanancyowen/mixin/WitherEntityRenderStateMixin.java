package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.render.entity.state.WitherEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@SuppressWarnings("all")
@Mixin(WitherEntityRenderState.class)
public abstract class WitherEntityRenderStateMixin implements RenderStateExtender {
    @Unique private int charge;
    @Unique private int slam;
    @Unique private boolean blue;
    @Override public Object getThis(int i) {
        if(i == 0) return charge;
        if(i == 1) return slam;
        if(i == 2) return blue;
        return i;
    }
    @Override public void setThis(int i, Object toSet) {
        if(i == 0 && toSet instanceof Integer i2) charge = i2;
        if(i == 1 && toSet instanceof Integer i2) slam = i2;
        if(i == 2 && toSet instanceof Boolean b) blue = b;
    }
}
