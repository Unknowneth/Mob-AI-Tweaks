package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@SuppressWarnings("all")
@Mixin(LivingEntityRenderState.class)
public abstract class LivingEntityRenderStateMixin implements RenderStateExtender {
    @Unique private float tickDelta;
    @Unique private int special;
    @Unique private boolean burning;
    @Unique private boolean freezing;
    @Unique private boolean crossbow;
    @Override public Object getThis(int i) {
        if(i == 0) return special;
        if(i == 1) return burning;
        if(i == 2) return freezing;
        if(i == 3) return tickDelta;
        if(i == 4) return crossbow;
        return tickDelta;
    }
    @Override public void setThis(int i, Object toSet) {
        if(i == 0 && toSet instanceof Integer i2) special = i2;
        if(i == 1 && toSet instanceof Boolean b1) burning = b1;
        if(i == 2 && toSet instanceof Boolean b2) freezing = b2;
        if(i == 3 && toSet instanceof Float f) tickDelta = f;
        if(i == 4 && toSet instanceof Boolean b3) crossbow = b3;
    }
}
