package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.ArmPosing;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.ZombieVillagerEntityModel;
import net.minecraft.client.render.entity.state.ZombieVillagerRenderState;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ZombieVillagerEntityModel.class)
public abstract class ZombieVillagerEntityModelMixin<S extends ZombieVillagerRenderState> extends BipedEntityModel<S> {
    ZombieVillagerEntityModelMixin(ModelPart root) {
        super(root);
    }
    @Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/ZombieVillagerRenderState;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/model/ArmPosing;zombieArms(Lnet/minecraft/client/model/ModelPart;Lnet/minecraft/client/model/ModelPart;ZFF)V"), cancellable = true)
    private void crossbowHoldingAnimation(ZombieVillagerRenderState state, CallbackInfo ci) {
        if(state instanceof RenderStateExtender r && r.getThis(4) instanceof Boolean b && b) {
            if(state.isUsingItem) ArmPosing.charge(getArm(state.mainArm), getArm(state.mainArm == Arm.LEFT ? Arm.RIGHT : Arm.LEFT), state.crossbowPullTime, state.itemUseTime, state.mainArm == Arm.RIGHT);
            else ArmPosing.hold(getArm(state.mainArm), getArm(state.mainArm == Arm.LEFT ? Arm.RIGHT : Arm.LEFT), head, state.mainArm == Arm.RIGHT);
            ci.cancel();
        }
    }
}
