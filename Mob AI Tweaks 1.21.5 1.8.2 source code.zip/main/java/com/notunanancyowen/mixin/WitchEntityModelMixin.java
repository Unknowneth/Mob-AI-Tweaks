package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.render.entity.model.WitchEntityModel;
import net.minecraft.client.render.entity.state.WitchEntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.WitchEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(WitchEntityModel.class)
public abstract class WitchEntityModelMixin {
    @Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/WitchEntityRenderState;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/ModelPart;setOrigin(FFF)V"), cancellable = true)
    private void doNotRaiseNose(WitchEntityRenderState witchEntityRenderState, CallbackInfo ci) {
        if(witchEntityRenderState instanceof RenderStateExtender r && r.getThis(4) instanceof Boolean b && !b) ci.cancel();
    }
}
