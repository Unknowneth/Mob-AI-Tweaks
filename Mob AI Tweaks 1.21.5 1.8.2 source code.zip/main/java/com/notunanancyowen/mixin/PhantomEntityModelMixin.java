package com.notunanancyowen.mixin;

import com.notunanancyowen.client.PhantomEyesFeature;
import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.render.entity.model.PhantomEntityModel;
import net.minecraft.client.render.entity.state.PhantomEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PhantomEntityModel.class)
public abstract class PhantomEntityModelMixin {
    @Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/PhantomEntityRenderState;)V", at = @At("HEAD"), require = 0)
    private void isBossPhantom(PhantomEntityRenderState phantomEntityRenderState, CallbackInfo ci) {
        if(phantomEntityRenderState instanceof RenderStateExtender r && r.getThis(4) instanceof Boolean b && b) PhantomEyesFeature.largePhantoms.add((PhantomEntityModel)(Object)this);
    }
}
