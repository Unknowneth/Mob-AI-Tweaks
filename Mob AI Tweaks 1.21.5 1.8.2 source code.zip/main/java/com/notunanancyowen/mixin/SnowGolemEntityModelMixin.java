package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.SnowGolemEntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SnowGolemEntityModel.class)
public abstract class SnowGolemEntityModelMixin {
    @Shadow @Final private ModelPart rightArm;
    @Shadow @Final private ModelPart leftArm;
    @Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;)V", at = @At("TAIL"))
    private void addArmAnimations(LivingEntityRenderState livingEntityRenderState, CallbackInfo ci) {
        rightArm.roll = -(float)Math.PI / 3F;
        leftArm.roll = (float)Math.PI / 3F;
        if(livingEntityRenderState instanceof RenderStateExtender r && r.getThis(4) instanceof Boolean b) if(b) {
            float h = r.getThis(3) instanceof Float f ? f : 0F;
            int s = r.getThis(0) instanceof Integer i ? i : 0;
            if(s == 0) h = 0F;
            leftArm.yaw = -(float)Math.PI * 2F * (0.1F * (h + (10 - s)) - 0.5F) - (float)Math.PI;
            leftArm.roll = -(float)Math.PI / 3F * (1.5F + (float)Math.cos(leftArm.yaw) * 0.5F) + (float)Math.PI;
            float d = 1.0F + 0.2F * (float)Math.abs(Math.sin(leftArm.yaw));
            leftArm.originX *= d;
            leftArm.originZ *= d;
            if(s == 9) rightArm.roll = -h * (float)Math.PI / 3F;
        }
        else {
            float h = r.getThis(3) instanceof Float f ? f : 0F;
            int s = r.getThis(0) instanceof Integer i ? i : 0;
            if(s == 0) h = 0F;
            rightArm.yaw = (float)Math.PI * 2F * (0.1F * (h + (10 - s)) + 0.5F);
            rightArm.roll = -(float)Math.PI / 3F * (1.5F + (float)Math.cos(rightArm.yaw) * 0.5F);
            float d = 1.0F + 0.2F * (float)Math.abs(Math.sin(rightArm.yaw));
            rightArm.originX *= d;
            rightArm.originZ *= d;
            if(s == 9) leftArm.roll = h * (float)Math.PI / 3F;
        }
    }
}
