package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.render.entity.state.GhastEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@SuppressWarnings("all")
@Mixin(GhastEntityRenderState.class)
public abstract class GhastEntityRenderStateMixin implements RenderStateExtender {
    @Unique private int special;
    @Override public Object getThis(int i) {
        return special;
    }
    @Override public void setThis(int i, Object toSet) {
        if(toSet instanceof Integer i2) special = i2;
    }
}
