package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.DrownedEntityModel;
import net.minecraft.client.render.entity.model.ZombieEntityModel;
import net.minecraft.client.render.entity.state.ZombieEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = DrownedEntityModel.class, priority = 999)
public abstract class DrownedEntityModelMixin extends ZombieEntityModel<ZombieEntityRenderState> {
    DrownedEntityModelMixin(ModelPart modelPart) {
        super(modelPart);
    }
    @Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/ZombieEntityRenderState;)V", at = @At("TAIL"))
    private void fixHeadRotation(ZombieEntityRenderState zombieEntityRenderState, CallbackInfo ci) {
        if(zombieEntityRenderState.leaningPitch > 0F && MobAITweaks.getModConfigValue("drowned_swimming_animation")) head.pitch -= zombieEntityRenderState.leaningPitch;
    }
}
