package com.notunanancyowen.mixin;

import com.notunanancyowen.dataholders.RenderStateExtender;
import net.minecraft.client.render.entity.state.ShulkerBulletEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@SuppressWarnings("all")
@Mixin(ShulkerBulletEntityRenderState.class)
public abstract class ShulkerBulletRenderStateMixin implements RenderStateExtender {
    @Unique int variant;
    @Override public Object getThis(int i) {
        return variant;
    }
    @Override public void setThis(int i, Object toSet) {
        if(toSet instanceof Integer i2) variant = i2;
    }
}
