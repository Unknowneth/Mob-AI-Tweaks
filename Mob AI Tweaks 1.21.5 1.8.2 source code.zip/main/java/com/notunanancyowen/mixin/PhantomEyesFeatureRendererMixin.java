package com.notunanancyowen.mixin;

import com.notunanancyowen.MobAITweaks;
import com.notunanancyowen.client.PhantomEyesFeature;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.feature.PhantomEyesFeatureRenderer;
import net.minecraft.client.render.entity.model.PhantomEntityModel;
import net.minecraft.client.render.entity.state.PhantomEntityRenderState;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PhantomEyesFeatureRenderer.class)
public abstract class PhantomEyesFeatureRendererMixin {
    @Unique private static final RenderLayer UPSCALED_SKIN = RenderLayer.getEyes(Identifier.of(MobAITweaks.MOD_ID, "textures/phantomare/eyes.png"));
    @Unique private PhantomEntityModel phantom;
    @Inject(method = "<init>", at = @At("TAIL"), require = 0)
    private void assignPhantom(FeatureRendererContext<PhantomEntityRenderState, PhantomEntityModel> featureRendererContext, CallbackInfo ci) {
        phantom = featureRendererContext.getModel();
    }
    @Inject(method = "getEyesTexture", at = @At("HEAD"), require = 0, cancellable = true)
    private void becomeMoreDetailed(CallbackInfoReturnable<RenderLayer> cir) {
        if(PhantomEyesFeature.largePhantoms.remove(phantom)) cir.setReturnValue(UPSCALED_SKIN);
    }
}
