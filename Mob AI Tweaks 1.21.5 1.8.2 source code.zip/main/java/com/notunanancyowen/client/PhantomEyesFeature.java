package com.notunanancyowen.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.model.PhantomEntityModel;

import java.util.ArrayList;

@Environment(EnvType.CLIENT)
public class PhantomEyesFeature {
    public static ArrayList<PhantomEntityModel> largePhantoms = new ArrayList<>();
}
