function mob-ai-tweaks:debug/door_zombie_summon_door with entity @s HandItems[0]
ride @n[tag=door_zombie,type=block_display] mount @s
item replace entity @s weapon.mainhand with air
tag @s add door_zombie