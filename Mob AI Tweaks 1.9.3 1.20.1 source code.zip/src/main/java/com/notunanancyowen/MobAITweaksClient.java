package com.notunanancyowen;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import oshi.util.tuples.Pair;

import java.io.*;
import java.util.HashMap;

import static com.notunanancyowen.MobAITweaks.MOD_ID;
import static com.notunanancyowen.MobAITweaks.LOGGER;

public class MobAITweaksClient implements ClientModInitializer {
    @Override public void onInitializeClient() {
        try {
            if(FabricLoader.getInstance().getConfigDir().resolve(MOD_ID).toFile().mkdir()) LOGGER.info("Added general directory!");
            if(FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + "/client").toFile().mkdir()) LOGGER.info("Added client directory!");
        }
        catch (SecurityException e) {
            LOGGER.info("Error making config directories: %n" + e.getLocalizedMessage());
        }
        String mobSitHeight = "#Example is as goes, mob-ai-tweaks:sittable_hostile_mob=height or mob-ai-tweaks:sittable_hostile_mob=[adult_height, baby_height], tags are not supported due to this being on the client";
        try {
            File config = FabricLoader.getInstance().getConfigDir().resolve(MOD_ID + "/client/hostiles_visual_sit_height_offset.txt").toFile();
            if(config.createNewFile()) try(FileWriter configWriter = new FileWriter(config)) {
                configWriter.write(mobSitHeight);
            }
            try(FileReader configReader = new FileReader(config)) {
                BufferedReader reader = new BufferedReader(configReader);
                StringBuilder bob = new StringBuilder();
                String configText;
                while((configText = reader.readLine()) != null) {
                    bob.append(configText);
                    bob.append(System.lineSeparator());
                }
                bob.deleteCharAt(bob.length() - 1);
                reader.close();
                bob.toString().lines().forEach(configContent -> {
                    if(!configContent.startsWith("#Example")) {
                        String[] configValues = configContent.split("=", 2);
                        if(!configValues[0].contains(":")) configValues[0] = "minecraft:" + configValues[0];
                        if(configValues[1].contains("[")) {
                            String[] configSeparator = configValues[1].replace("[", "").replace("]", "").replace(" ", "").split(",", 2);
                            for(int i = 0; i < configSeparator[0].length(); i++) if(configSeparator[0].charAt(i) != '.' && configSeparator[0].charAt(i) != '-' && !Character.isDigit(configSeparator[0].charAt(i))) return;
                            double result1 = Double.parseDouble(configSeparator[0]);
                            for(int i = 0; i < configSeparator[1].length(); i++) if(configSeparator[1].charAt(i) != '.' && configSeparator[1].charAt(i) != '-' && !Character.isDigit(configSeparator[1].charAt(i))) return;
                            double result2 = Double.parseDouble(configSeparator[1]);
                            MobAITweaksClient.mobSitHeight.put(configValues[0], new Pair<>(result1, result2));
                        }
                        else {
                            for(int i = 0; i < configValues[1].length(); i++) if(configValues[1].charAt(i) != '.' && configValues[1].charAt(i) != '-' && !Character.isDigit(configValues[1].charAt(i))) return;
                            double result = Double.parseDouble(configValues[1]);
                            MobAITweaksClient.mobSitHeight.put(configValues[0], new Pair<>(result, result));
                        }
                    }
                });
            }
        }
        catch (IOException | SecurityException e) {
            LOGGER.info("Error making config: %n" + e.getLocalizedMessage());
        }
    }
    public static final HashMap<String, Pair<Double, Double>> mobSitHeight = new HashMap<>();
}
